/**
 * يبني ملفات التنزيل من مخرجات `vite build --mode standalone`:
 *  1) public/download/standalone-template.html — التطبيق كاملًا بملف واحد يعمل دون إنترنت
 *  2) public/download/dj-muscat-project.zip    — نسخة المصدر الكامل للمشروع
 * يُشغَّل تلقائيًا عبر prebuild.
 */
import { readFileSync, writeFileSync, mkdirSync, rmSync, existsSync, cpSync, readdirSync } from 'fs';
import { execFileSync } from 'child_process';
import { join } from 'path';

const root = process.cwd();
const distDir = join(root, 'dist-standalone');
const outDir = join(root, 'public', 'download');
mkdirSync(outDir, { recursive: true });

// 1) standalone single-file app (image/svg embedded as data URIs)
if (!existsSync(join(distDir, 'index.html'))) {
  console.error('✖ dist-standalone/index.html غير موجود — شغّل npm run build:standalone أولًا');
  process.exit(1);
}
let html = readFileSync(join(distDir, 'index.html'), 'utf8');
const hero = readFileSync(join(root, 'public/images/hero-dj.jpg')).toString('base64');
html = html.split('/images/hero-dj.jpg').join(`data:image/jpeg;base64,${hero}`);
const pngDataUri = (p) => `data:image/png;base64,${readFileSync(join(root, p)).toString('base64')}`;
// كل مسارات الملفات تُضمَّن كـ data URIs ليعمل الملف المنفرد تحت file:// دون أي خادم
html = html.split('href="./favicon.svg"').join(
  'href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 64 64%22><rect width=%2264%22 height=%2264%22 rx=%2215%22 fill=%22%23F59E0B%22/><circle cx=%2232%22 cy=%2232%22 r=%2214%22 fill=%22none%22 stroke=%22white%22 stroke-width=%225%22/></svg>"'
);
// vite-plugin-singlefile يحوّل المسارات المطلقة إلى نسبية — نعالج الاثنين
// مانيفست مكتفٍ ذاتيًا داخل الملف المنفرد (أيقونات data URIs)
const icon192 = pngDataUri('public/icons/icon-192.png');
const icon512 = pngDataUri('public/icons/icon-512.png');
const standaloneManifest = {
  name: 'ديجي مسقط — سجل حجوزات الحفلات المحلية',
  short_name: 'ديجي مسقط',
  description: 'دفتر ذهبي لتسجيل وإدارة حجوزات الديجي المحلي للحفلات مع تذكير واتساب +968 تلقائي وإشعارات تحذير.',
  lang: 'ar', dir: 'rtl', start_url: '.', scope: '.',
  display: 'standalone', orientation: 'portrait',
  background_color: '#fdf6ea', theme_color: '#F59E0B',
  icons: [
    { src: icon192, sizes: '192x192', type: 'image/png', purpose: 'any maskable' },
    { src: icon512, sizes: '512x512', type: 'image/png', purpose: 'any maskable' },
  ],
};
for (const prefix of ['/', './']) {
  html = html.split(`href="${prefix}icons/icon-192.png"`).join(`href="${icon192}"`);
  html = html.split(`href="${prefix}icons/apple-touch-icon.png"`).join(`href="${pngDataUri('public/icons/apple-touch-icon.png')}"`);
  html = html.split(`src="${prefix}icons/icon-192.png"`).join(`src="${icon192}"`);
  html = html.split(`href="${prefix}manifest.webmanifest"`).join(
    `href="data:application/manifest+json;charset=utf-8,${encodeURIComponent(JSON.stringify(standaloneManifest))}"`
  );
}
writeFileSync(join(outDir, 'standalone-template.html'), html);
console.log(`✓ standalone-template.html (${(html.length / 1024 / 1024).toFixed(2)} MB)`);

// 2) source ZIP via system zip (excludes node_modules & build output)
const tmpRoot = join(root, '.zipbuild-tmp');
const zipStage = join(tmpRoot, 'dj-muscat-source');
rmSync(tmpRoot, { recursive: true, force: true });
mkdirSync(zipStage, { recursive: true });
const EXCLUDE = new Set(['node_modules', 'dist', 'dist-standalone', '.git', 'public/download', '.zipbuild-tmp', '.agon-env', '.vite-source-tags.js']);
const walk = (src, dest) => {
  for (const entry of readdirSync(src, { withFileTypes: true })) {
    const rel = join(src, entry.name).slice(root.length + 1);
    if (EXCLUDE.has(entry.name) || EXCLUDE.has(rel)) continue;
    const to = join(dest, entry.name);
    if (entry.isDirectory()) { mkdirSync(to, { recursive: true }); walk(join(src, entry.name), to); }
    else cpSync(join(src, entry.name), to);
  }
};
walk(root, zipStage);
rmSync(join(outDir, 'dj-muscat-project.zip'), { force: true });
execFileSync('zip', ['-r', '-X', 'dj-muscat-project.zip', 'dj-muscat-source'], { cwd: tmpRoot, stdio: 'ignore' });
cpSync(join(tmpRoot, 'dj-muscat-project.zip'), join(outDir, 'dj-muscat-project.zip'));
rmSync(tmpRoot, { recursive: true, force: true });
console.log('✓ dj-muscat-project.zip');
