import { Resvg } from '@resvg/resvg-js';
import { writeFileSync } from 'fs';

const svg = (size) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#1F1A17"/><stop offset="1" stop-color="#0F0D0B"/>
    </linearGradient>
    <radialGradient id="groove" cx="50%" cy="50%" r="50%">
      <stop offset="0.36" stop-color="#2E2C29"/><stop offset="0.38" stop-color="#3B3835"/>
      <stop offset="0.46" stop-color="#2E2C29"/><stop offset="0.48" stop-color="#3B3835"/>
      <stop offset="0.56" stop-color="#2E2C29"/><stop offset="0.58" stop-color="#3B3835"/>
      <stop offset="0.66" stop-color="#2E2C29"/><stop offset="0.68" stop-color="#3B3835"/>
      <stop offset="1" stop-color="#2E2C29"/>
    </radialGradient>
    <linearGradient id="disc" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#FBBF24"/><stop offset="0.42" stop-color="#F97316"/><stop offset="1" stop-color="#E11D48"/>
    </linearGradient>
  </defs>
  <rect width="${size}" height="${size}" rx="${size*0.225}" fill="url(#bg)"/>
  <circle cx="${size/2}" cy="${size/2}" r="${size*0.33}" fill="url(#groove)" stroke="#F5C97B" stroke-opacity="0.22" stroke-width="${size*0.008}"/>
  <circle cx="${size/2}" cy="${size/2}" r="${size*0.185}" fill="url(#disc)"/>
  <circle cx="${size/2}" cy="${size/2}" r="${size*0.072}" fill="#FFF7E6"/>
  <circle cx="${size/2}" cy="${size/2}" r="${size*0.024}" fill="#1F1A17"/>
  <path d="M ${size*0.79} ${size*0.16} l ${size*0.012} ${size*0.034} ${size*0.034} ${size*0.012} -${size*0.034} ${size*0.012} -${size*0.012} ${size*0.034} -${size*0.012} -${size*0.034} -${size*0.034} -${size*0.012} ${size*0.034} -${size*0.012} Z" fill="#FDE68A"/>
  <path d="M ${size*0.17} ${size*0.72} l ${size*0.009} ${size*0.024} ${size*0.024} ${size*0.009} -${size*0.024} ${size*0.009} -${size*0.009} ${size*0.024} -${size*0.009} -${size*0.024} -${size*0.024} -${size*0.009} ${size*0.024} -${size*0.009} Z" fill="#F9A8D4" opacity="0.9"/>
</svg>`;

for (const size of [512, 192, 180]) {
  const name = size === 180 ? 'apple-touch-icon.png' : `icon-${size}.png`;
  const resvg = new Resvg(svg(size), { fitTo: { mode: 'width', value: size } });
  writeFileSync(`public/icons/${name}`, resvg.render().asPng());
  console.log('written', name);
}
