import { useCallback, useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import confetti from 'canvas-confetti';
import {
  Trash2, X, AlertTriangle, Music4, MapPin, Phone, Clock, MessageCircle,
  BellRing, BellOff, Sparkles, BadgeCheck, ShieldCheck, ChevronUp,
} from 'lucide-react';

import TopBar from './components/TopBar';
import Hero from './components/Hero';
import BookingForm from './components/BookingForm';
import BookingList from './components/BookingList';
import StatsPanel from './components/StatsPanel';
import AlertsSection from './components/AlertsSection';
import DownloadSection from './components/DownloadSection';
import ToastStack from './components/Toast';

import type { Booking, ToastItem, ToastKind } from './lib/types';
import { computeAlerts, isPaymentOverdue, remaining, uid } from './lib/utils';
import { seedBookings, printBooking } from './lib/seed';

const STORAGE_KEY = 'dj-muscat-bookings-v1';

function loadBookings(): Booking[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Booking[];
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    /* corrupted storage -> reseed */
  }
  return seedBookings();
}

export default function App() {
  const [bookings, setBookings] = useState<Booking[]>(() => loadBookings());
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [editing, setEditing] = useState<Booking | null>(null);
  const [savedSlip, setSavedSlip] = useState<Booking | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Booking | null>(null);
  const [clearAllConfirm, setClearAllConfirm] = useState(false);
  const [notifPerm, setNotifPerm] = useState<NotificationPermission>(() =>
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'denied'
  );
  const [showTop, setShowTop] = useState(false);

  /* ---- persist ---- */
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
    } catch {
      /* storage full */
    }
  }, [bookings]);

  /* ---- derived alerts ---- */
  const alerts = useMemo(() => computeAlerts(bookings), [bookings]);
  const overdueAlerts = useMemo(() => alerts.filter((a) => a.kind === 'overdue'), [alerts]);

  /* ---- toasts ---- */
  const pushToast = useCallback((kind: ToastKind, title: string, msg?: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, kind, title, msg }]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 6500);
  }, []);
  const dismissToast = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  const fireConfetti = useCallback(() => {
    const colors = ['#F59E0B', '#FB923C', '#E11D48', '#A855F7', '#34D399', '#38BDF8', '#FDE047'];
    confetti({ particleCount: 120, spread: 90, startVelocity: 38, origin: { y: 0.72 }, colors });
    window.setTimeout(() => confetti({ particleCount: 70, spread: 120, startVelocity: 28, origin: { y: 0.4, x: 0.15 }, colors }), 220);
    window.setTimeout(() => confetti({ particleCount: 70, spread: 120, startVelocity: 28, origin: { y: 0.4, x: 0.85 }, colors }), 320);
  }, []);

  /* ---- phone (browser) notifications for warnings ---- */
  const sendPhoneAlerts = useCallback(
    (list: typeof alerts, force = false) => {
      if (!('Notification' in window)) return;
      if (Notification.permission !== 'granted') return;
      const overdue = list.filter((a) => a.kind === 'overdue');
      const urgent = list.filter((a) => a.kind === 'today' || a.kind === 'tomorrow');
      const merged = [...overdue, ...urgent];
      if (merged.length === 0 && !force) return;
      merged.slice(0, 4).forEach((a) => {
        try {
          const n = new Notification(a.title, { body: a.body, icon: '/favicon.svg', tag: a.id, requireInteraction: a.kind === 'overdue' });
          n.onclick = () => {
            window.focus();
            if (a.waLink) window.open(a.waLink, '_blank');
            n.close();
          };
        } catch {
          /* some browsers require SW — in-app toast remains */
        }
      });
    },
    []
  );

  useEffect(() => {
    if (notifPerm === 'granted' && overdueAlerts.length > 0) {
      const t = window.setTimeout(() => sendPhoneAlerts(alerts), 1800);
      return () => window.clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notifPerm, overdueAlerts.length]);

  // re-check every 10 minutes (catches the 3-day threshold while app is open)
  useEffect(() => {
    const iv = window.setInterval(() => sendPhoneAlerts(computeAlerts(bookings)), 10 * 60 * 1000);
    return () => window.clearInterval(iv);
  }, [bookings, sendPhoneAlerts]);

  const requestNotifPermission = useCallback(async () => {
    if (!('Notification' in window)) {
      pushToast('error', 'المتصفح لا يدعم الإشعارات', 'استخدم Chrome على Android أو Safari على iPhone لتفعيل إشعارات الهاتف');
      return;
    }
    const perm = await Notification.requestPermission();
    setNotifPerm(perm);
    if (perm === 'granted') {
      pushToast('success', 'تم تفعيل إشعارات الهاتف ✓', 'ستصلك تحذيرات المتبقي والسداد المتأخر على جهازك فورًا');
      sendPhoneAlerts(alerts, true);
    } else if (perm === 'denied') {
      pushToast('warning', 'الإشعارات محظورة من المتصفح', 'يمكنك تفعيلها يدويًا من إعدادات الموقع في المتصفح');
    }
  }, [alerts, pushToast, sendPhoneAlerts]);

  /* ---- CRUD ---- */
  const handleSave = useCallback(
    (data: Omit<Booking, 'id' | 'createdAt'>, existingId?: string) => {
      if (existingId) {
        setBookings((prev) => prev.map((b) => (b.id === existingId ? { ...b, ...data } : b)));
        setSavedSlip(null);
        setEditing(null);
        pushToast('success', 'تم تحديث الحجز بنجاح', `حجز «${data.ownerName}» انحفظ بالتعديلات الجديدة`);
        return;
      }
      const created: Booking = { ...data, id: uid(), createdAt: new Date().toISOString() };
      setBookings((prev) => [created, ...prev]);
      setSavedSlip(created);
      fireConfetti();
      pushToast('success', 'تم حفظ الحجز في السجلّ!', `أهلًا بحفل «${data.ownerName}» — ${data.category}`);
      // phone warning if created already-overdue is impossible, but notify about existing overdues once
      window.setTimeout(() => sendPhoneAlerts(computeAlerts([created, ...bookings])), 800);
    },
    [bookings, fireConfetti, pushToast, sendPhoneAlerts]
  );

  const handleEdit = useCallback((b: Booking) => {
    setSavedSlip(null);
    setEditing({ ...b });
    window.setTimeout(() => document.getElementById('new-booking')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
  }, []);

  const handleEditById = useCallback(
    (id: string) => {
      const b = bookings.find((x) => x.id === id);
      if (b) handleEdit(b);
    },
    [bookings, handleEdit]
  );

  const confirmDelete = useCallback(() => {
    if (!deleteTarget) return;
    setBookings((prev) => prev.filter((b) => b.id !== deleteTarget.id));
    if (savedSlip?.id === deleteTarget.id) setSavedSlip(null);
    if (editing?.id === deleteTarget.id) setEditing(null);
    pushToast('info', 'تم حذف الحجز', `أُزيل حجز «${deleteTarget.ownerName}» من السجلّ نهائيًا`);
    setDeleteTarget(null);
  }, [deleteTarget, editing?.id, savedSlip?.id, pushToast]);

  const handleMarkPaid = useCallback(
    (b: Booking) => {
      setBookings((prev) => prev.map((x) => (x.id === b.id ? { ...x, paidAmount: x.totalAmount } : x)));
      pushToast('success', 'اكتمل السداد!', `تم تسجيل دفع المبلغ كاملًا لحفل «${b.ownerName}» — المتبقي صفر`);
      fireConfetti();
    },
    [fireConfetti, pushToast]
  );

  const handleClearAll = useCallback(() => {
    setBookings([]);
    setSavedSlip(null);
    setEditing(null);
    setClearAllConfirm(false);
    pushToast('warning', 'تم مسح كل الحجوزات', 'يمكنك استعادة البيانات بإعادة تحميل الصفحة لأول مرة… أو أضف حجوزات جديدة');
  }, [pushToast]);

  const scrollToForm = useCallback(() => {
    setSavedSlip(null);
    setEditing(null);
    document.getElementById('new-booking')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, []);

  const scrollToBookings = useCallback(() => {
    document.getElementById('bookings')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, []);

  /* ---- back-to-top visibility ---- */
  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 480);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="app-bg min-h-screen font-cairo text-stone-800">
      <TopBar alerts={alerts} overdueCount={overdueAlerts.length} onNewBooking={scrollToForm} />

      <Hero bookings={bookings} onNewBooking={scrollToForm} onViewBookings={scrollToBookings} />

      {/* ===== main content: form + alerts aside ===== */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 xl:grid-cols-3 gap-5 xl:gap-6 items-start">
        <div className="xl:col-span-2 -mx-4 sm:-mx-6 xl:mx-0">
          <BookingForm
            editing={editing}
            onSave={handleSave}
            savedSlip={savedSlip}
            onDismissSlip={() => setSavedSlip(null)}
            onEditSlip={(b) => { setSavedSlip(null); setEditing(b); }}
          />
        </div>

        <aside className="xl:col-span-1 space-y-4 pb-2">
          {/* phone notification opt-in card */}
          <div className="rounded-[26px] border-2 border-sky-200 bg-gradient-to-br from-sky-50 via-cyan-50 to-teal-50 p-4 shadow-sm">
            <div className="flex items-start gap-3">
              <span className="w-11 h-11 shrink-0 rounded-2xl bg-gradient-to-br from-sky-400 to-blue-600 text-white flex items-center justify-center shadow">
                {notifPerm === 'granted' ? <BellRing className="w-6 h-6" /> : <BellOff className="w-6 h-6" />}
              </span>
              <div className="min-w-0">
                <p className="font-lalezar text-[15px] text-stone-900">إشعارات التحذير على هاتفك</p>
                <p className="text-[10px] sm:text-[10.5px] font-bold text-stone-500 leading-relaxed mt-0.5">
                  {notifPerm === 'granted'
                    ? 'مفعّلة ✓ — سيصلك تنبيه لحظي فور تأخر أي حجز عن السداد أكثر من 3 أيام أو قرب موعد حفل.'
                    : 'فعّل الإشعارات لتصلك تحذيرات المتأخرات وموعد الحفل الليلة والغد مباشرة على شاشة هاتفك.'}
                </p>
                {notifPerm !== 'granted' && (
                  <button onClick={requestNotifPermission} className="mt-2 inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-sky-500 to-blue-600 text-white text-[11px] font-black px-4 py-2 shadow hover:shadow-md transition-all">
                    <BellRing className="w-4 h-4" /> تفعيل إشعارات الهاتف الآن
                  </button>
                )}
                {notifPerm === 'granted' && (
                  <button onClick={() => sendPhoneAlerts(alerts, true)} className="mt-2 inline-flex items-center gap-1.5 rounded-xl bg-white border-2 border-sky-300 text-sky-800 text-[10.5px] font-black px-3.5 py-1.5 hover:bg-sky-100 transition-all">
                    <Sparkles className="w-4 h-4" /> جرّب إشعار تجريبي
                  </button>
                )}
              </div>
            </div>
          </div>

          <AlertsSection alerts={alerts} onEditBooking={handleEditById} />
        </aside>
      </div>

      {/* ===== bookings list ===== */}
      <div className="pt-2">
        <BookingList
          bookings={bookings}
          onEdit={handleEdit}
          onDelete={setDeleteTarget}
          onMarkPaid={handleMarkPaid}
          onPrint={printBooking}
          onClearAll={() => setClearAllConfirm(true)}
        />
      </div>

      <StatsPanel bookings={bookings} />

      <DownloadSection bookings={bookings} pushToast={pushToast} />

      {/* ===== features strip ===== */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-12">
        <div className="rounded-[26px] border-2 border-amber-200 bg-white/70 backdrop-blur px-5 py-5 grid grid-cols-2 md:grid-cols-4 gap-3 text-center shadow-sm">
          {[
            { Ico: BadgeCheck, t: 'بيانات موثقة', s: 'كل حجز بأيقوناته وتاريخه الهجري' },
            { Ico: MessageCircle, t: 'واتساب +968 تلقائي', s: 'تذكير السداد بعد 3 أيام تلقائيًا' },
            { Ico: BellRing, t: 'إشعارات تحذير', s: 'تنبيه فوري على الهاتف قبل الحفل' },
            { Ico: ShieldCheck, t: 'محلي 100%', s: 'بياناتك محفوظة على جهازك — CSV وJSON' },
          ].map((f, i) => (
            <div key={i} className="flex flex-col items-center gap-1.5">
              <f.Ico className="w-7 h-7 text-orange-500" strokeWidth={1.9} />
              <p className="text-[11.5px] font-black text-stone-800">{f.t}</p>
              <p className="text-[9px] sm:text-[9.5px] font-bold text-stone-500 leading-relaxed">{f.s}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ===== footer ===== */}
      <footer className="relative bg-stone-900 text-amber-50 overflow-hidden">
        <div className="h-1.5 w-full bg-gradient-to-l from-amber-400 via-rose-500 to-fuchsia-600" />
        <div className="absolute -top-24 right-1/4 w-72 h-72 rounded-full bg-orange-600/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 left-1/4 w-72 h-72 rounded-full bg-fuchsia-600/10 blur-3xl pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-9 relative">
          <div className="grid md:grid-cols-3 gap-6 items-start">
            <div className="flex items-center gap-3">
              <span className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 via-orange-500 to-rose-600 flex items-center justify-center shadow-lg shadow-orange-900/40">
                <Music4 className="w-8 h-8 text-white" />
              </span>
              <div>
                <p className="font-lalezar text-2xl text-amber-100">ديجي <span className="text-amber-400">مسقط</span></p>
                <p className="text-[10px] font-bold text-amber-200/70">الدفتر الذهبي لتسجيل حجوزات الديجي المحلية للحفلات منذ 2011</p>
              </div>
            </div>
            <div className="text-[11px] font-bold text-amber-100/80 space-y-1.5">
              <p className="flex items-center gap-2"><MapPin className="w-4 h-4 text-amber-400 shrink-0" /> مسقط • السيب • بوشر • بركاء • نزوى</p>
              <a href="tel:+96891234567" className="flex items-center gap-2 hover:text-white transition-colors" dir="ltr"><Phone className="w-4 h-4 text-amber-400 shrink-0" /> +968 9123 4567</a>
              <p className="flex items-center gap-2"><Clock className="w-4 h-4 text-amber-400 shrink-0" /> يوميًا من 9 صباحًا حتى 11 مساءً — الحجوزات على مدار الساعة</p>
            </div>
            <div className="md:justify-self-end w-full md:w-auto">
              <a href="https://wa.me/96891234567?text=السلام%20عليكم%20ديجي%20مسقط%20🎧%20حاب%20أحجز%20حفل" target="_blank" rel="noreferrer"
                 className="flex items-center justify-center gap-2 rounded-2xl bg-[#25D366] hover:bg-[#1fb855] text-white font-black text-[13px] px-6 py-3.5 shadow-lg shadow-green-900/40 transition-all">
                <MessageCircle className="w-5 h-5" fill="#fff" /> احجز حفلتك الآن عبر واتساب
              </a>
              <p className="text-center text-[9px] font-bold text-amber-200/50 mt-2">جميع البيانات محفوظة محليًا على هذا الجهاز — صدّر نسخة احتياطية من السجلّ بالأسفل</p>
            </div>
          </div>
          <div className="border-t border-white/10 mt-6 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-[9.5px] font-bold text-amber-100/50">
            <p>© {new Date().getFullYear()} ديجي مسقط — نظام إدارة حجوزات الحفلات المحلية</p>
            <p>صُنع بإتقان في سلطنة عُمان 🇴🇲 • React + Tailwind</p>
          </div>
        </div>
      </footer>

      {/* ===== back to top ===== */}
      <AnimatePresence>
        {showTop && (
          <motion.button
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 24 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-24 sm:bottom-8 left-4 sm:left-6 z-[60] w-12 h-12 rounded-2xl bg-stone-900 text-amber-400 border-2 border-amber-500/50 shadow-xl flex items-center justify-center hover:bg-stone-800 transition-colors"
            aria-label="العودة للأعلى"
          >
            <ChevronUp className="w-6 h-6" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* ===== delete confirm modal ===== */}
      <AnimatePresence>
        {deleteTarget && (
          <motion.div key="del" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[65] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-stone-950/60 backdrop-blur-sm" onClick={() => setDeleteTarget(null)} />
            <motion.div
              initial={{ scale: 0.85, y: 40 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 320, damping: 26 }}
              className="relative w-full max-w-md rounded-[26px] border-2 border-rose-300 bg-white shadow-2xl overflow-hidden"
            >
              <div className="bg-gradient-to-l from-rose-500 to-red-600 px-6 py-4 flex items-center gap-3 text-white">
                <AlertTriangle className="w-8 h-8" strokeWidth={2} />
                <div>
                  <h3 className="font-lalezar text-xl leading-none">حذف الحجز</h3>
                  <p className="text-[10px] font-bold text-rose-100 mt-1">هذا الإجراء لا يمكن التراجع عنه</p>
                </div>
                <button onClick={() => setDeleteTarget(null)} className="mr-auto p-2 rounded-xl hover:bg-white/15"><X className="w-5 h-5" /></button>
              </div>
              <div className="p-5">
                <p className="text-[13px] font-bold text-stone-700 leading-7">
                  سيتم حذف حجز <span className="text-rose-700">«{deleteTarget.ownerName}»</span> المقام في <span className="text-rose-700">{deleteTarget.venue}</span> بتاريخ <span className="num text-rose-700">{deleteTarget.eventDate}</span> نهائيًا من السجلّ.
                </p>
                <div className="flex gap-2 mt-4">
                  <button onClick={confirmDelete} className="flex-1 inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 font-lalezar text-[15px] text-white bg-gradient-to-l from-rose-500 to-red-600 border border-red-700 shadow-lg hover:-translate-y-0.5 transition-all">
                    <Trash2 className="w-5 h-5" /> نعم، احذف الحجز
                  </button>
                  <button onClick={() => setDeleteTarget(null)} className="rounded-2xl px-6 py-3.5 font-black text-[13px] text-stone-600 bg-stone-100 border-2 border-stone-200 hover:bg-stone-200 transition-all">إلغاء</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}

        {clearAllConfirm && (
          <motion.div key="clear" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[65] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-stone-950/60 backdrop-blur-sm" onClick={() => setClearAllConfirm(false)} />
            <motion.div
              initial={{ scale: 0.85, y: 40 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 320, damping: 26 }}
              className="relative w-full max-w-md rounded-[26px] border-2 border-rose-300 bg-white shadow-2xl overflow-hidden"
            >
              <div className="bg-gradient-to-l from-rose-500 to-red-600 px-6 py-4 flex items-center gap-3 text-white">
                <AlertTriangle className="w-8 h-8" strokeWidth={2} />
                <h3 className="font-lalezar text-xl leading-none">مسح كل الحجوزات</h3>
                <button onClick={() => setClearAllConfirm(false)} className="mr-auto p-2 rounded-xl hover:bg-white/15"><X className="w-5 h-5" /></button>
              </div>
              <div className="p-5">
                <p className="text-[13px] font-bold text-stone-700 leading-7">سيتم حذف <span className="num text-rose-700">{bookings.length}</span> حجزًا نهائيًا. ننصحك بتصدير نسخة احتياطية (JSON) قبل المتابعة.</p>
                <div className="flex gap-2 mt-4">
                  <button onClick={handleClearAll} className="flex-1 inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 font-lalezar text-[15px] text-white bg-gradient-to-l from-rose-500 to-red-600 border border-red-700 shadow-lg transition-all">
                    <Trash2 className="w-5 h-5" /> مسح الكل نهائيًا
                  </button>
                  <button onClick={() => setClearAllConfirm(false)} className="rounded-2xl px-6 py-3.5 font-black text-[13px] text-stone-600 bg-stone-100 border-2 border-stone-200 hover:bg-stone-200 transition-all">إلغاء</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <ToastStack toasts={toasts} dismiss={dismissToast} />
    </div>
  );
}
