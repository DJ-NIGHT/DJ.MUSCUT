const BARS = [
  { h: 46, cls: 'eq-1', c: '#FBBF24' }, { h: 78, cls: 'eq-2', c: '#FB923C' }, { h: 58, cls: 'eq-3', c: '#F472B6' },
  { h: 92, cls: 'eq-4', c: '#E879F9' }, { h: 64, cls: 'eq-5', c: '#A78BFA' }, { h: 84, cls: 'eq-1', c: '#34D399' },
  { h: 52, cls: 'eq-2', c: '#38BDF8' }, { h: 96, cls: 'eq-3', c: '#FBBF24' }, { h: 70, cls: 'eq-4', c: '#FB7185' },
  { h: 88, cls: 'eq-5', c: '#FB923C' }, { h: 56, cls: 'eq-1', c: '#F472B6' }, { h: 74, cls: 'eq-2', c: '#A78BFA' },
  { h: 62, cls: 'eq-3', c: '#34D399' }, { h: 90, cls: 'eq-4', c: '#38BDF8' }, { h: 48, cls: 'eq-5', c: '#FBBF24' },
  { h: 80, cls: 'eq-2', c: '#E879F9' }, { h: 68, cls: 'eq-1', c: '#FB923C' }, { h: 56, cls: 'eq-3', c: '#FB7185' },
];

export default function HeroEq() {
  return (
    <div dir="ltr" className="flex items-end justify-center gap-[5px] h-28 sm:h-32 rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-transparent px-4 pt-3 pb-2">
      {BARS.map((b, i) => (
        <div
          key={i}
          className={`eq-bar w-[9px] sm:w-[11px] ${b.cls}`}
          style={{ height: `${b.h}%`, background: `linear-gradient(to top, ${b.c}, ${b.c}88)` }}
        />
      ))}
    </div>
  );
}
