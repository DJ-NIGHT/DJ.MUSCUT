import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User, Phone, MapPin, Mic2, Drum, CalendarDays, Clock, Wallet, Banknote, PiggyBank,
  PencilLine, Trash2, CheckCircle2, MessageCircle, ChevronDown, BadgePercent, Printer, StickyNote,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { Booking } from '../lib/types';
import { OMR, daysUntil, formatArabicDate, isPaymentOverdue, paidPercent, payStatusOf, remaining, timeAgoAr, toHijri, waLinkFor } from '../lib/utils';

const CAT: Record<string, { chip: string; edge: string; dot: string }> = {
  'زفاف': { chip: 'bg-pink-100 text-pink-800 border-pink-300', edge: 'from-pink-400 to-rose-500', dot: '#ec4899' },
  'خطوبة': { chip: 'bg-fuchsia-100 text-fuchsia-800 border-fuchsia-300', edge: 'from-fuchsia-400 to-purple-600', dot: '#d946ef' },
  'تخرج': { chip: 'bg-sky-100 text-sky-800 border-sky-300', edge: 'from-sky-400 to-blue-600', dot: '#0ea5e9' },
  'عقيقة': { chip: 'bg-teal-100 text-teal-800 border-teal-300', edge: 'from-teal-400 to-emerald-600', dot: '#14b8a6' },
  'حفل شركة': { chip: 'bg-violet-100 text-violet-800 border-violet-300', edge: 'from-violet-400 to-purple-600', dot: '#8b5cf6' },
  'ذكرى سنوية': { chip: 'bg-amber-100 text-amber-800 border-amber-300', edge: 'from-amber-400 to-orange-500', dot: '#f59e0b' },
};

const PAY: Record<string, { chip: string; label: string }> = {
  paid: { chip: 'bg-emerald-100 text-emerald-800 border-emerald-300', label: 'مدفوع بالكامل' },
  partial: { chip: 'bg-amber-100 text-amber-900 border-amber-300', label: 'دفعة جزئية' },
  unpaid: { chip: 'bg-rose-100 text-rose-800 border-rose-300', label: 'غير مدفوع' },
};

interface Props {
  booking: Booking;
  onEdit: (b: Booking) => void;
  onDelete: (b: Booking) => void;
  onMarkPaid: (b: Booking) => void;
  onPrint: (b: Booking) => void;
}

function Row({ icon: Icon, label, value, tone, dir }: { icon: LucideIcon; label: string; value: string; tone: string; dir?: 'ltr' | 'rtl' }) {
  return (
    <div className="flex items-center gap-2 min-w-0">
      <span className={`w-7 h-7 shrink-0 rounded-lg flex items-center justify-center ${tone}`}>
        <Icon className="w-4 h-4" strokeWidth={2.2} />
      </span>
      <span className="min-w-0">
        <span className="block text-[8.5px] font-black text-stone-400 leading-none mb-0.5">{label}</span>
        <span className="block text-[11.5px] font-extrabold text-stone-800 leading-snug truncate" dir={dir} title={value}>{value}</span>
      </span>
    </div>
  );
}

export default function BookingCard({ booking: b, onEdit, onDelete, onMarkPaid, onPrint }: Props) {
  const [expanded, setExpanded] = useState(false);
  const rem = remaining(b.totalAmount, b.paidAmount);
  const pct = paidPercent(b.totalAmount, b.paidAmount);
  const st = payStatusOf(b.totalAmount, b.paidAmount);
  const overdue = isPaymentOverdue(b);
  const dLeft = daysUntil(b.eventDate);
  const cat = CAT[b.category] ?? CAT['زفاف'];

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 26 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.85, height: 0, marginBottom: 0 }}
      transition={{ type: 'spring', stiffness: 240, damping: 26 }}
      className={`relative rounded-3xl border-2 bg-white shadow-[0_14px_40px_-18px_rgba(120,80,20,0.35)] overflow-hidden transition-shadow hover:shadow-[0_22px_55px_-18px_rgba(180,90,20,0.45)] ${overdue ? 'border-rose-400 ring-2 ring-rose-300/60' : 'border-amber-200/90'}`}
    >
      {/* category gradient edge (right side, RTL start) */}
      <span className={`absolute top-0 bottom-0 right-0 w-[7px] bg-gradient-to-b ${cat.edge}`} />

      <div className="pr-4 pl-3 py-3 sm:pr-5 sm:pl-4">
        {/* ---- header: owner + chips ---- */}
        <div className="flex items-start gap-2.5">
          <span className="w-12 h-12 shrink-0 rounded-2xl bg-gradient-to-br from-amber-100 to-orange-100 border-2 border-amber-200 flex items-center justify-center font-lalezar text-lg text-orange-700">
            {b.ownerName.trim().charAt(0)}
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="font-black text-[14px] sm:text-[15px] text-stone-900 leading-snug">{b.ownerName}</h3>
            <a href={`tel:${b.ownerPhone.replace(/[^+\d]/g, '')}`} className="num inline-flex items-center gap-1.5 text-[11px] sm:text-[11.5px] font-black text-sky-800 hover:text-sky-600 mt-0.5" dir="ltr">
              <Phone className="w-3.5 h-3.5" /> {b.ownerPhone}
            </a>
            <p className="text-[8.5px] font-bold text-stone-400 mt-0.5">أُنشئ الحجز {timeAgoAr(b.createdAt)}</p>
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            <span className={`rounded-full border px-2 py-0.5 text-[9.5px] font-black ${cat.chip}`}>{b.category}</span>
            <span className={`rounded-full border px-2 py-0.5 text-[9.5px] font-black ${PAY[st].chip}`}>{PAY[st].label}</span>
          </div>
        </div>

        {/* ---- icon chip grid ---- */}
        <div className="grid grid-cols-2 gap-x-2 gap-y-2 mt-3 rounded-2xl bg-sand bg-[#FFFBF1] border border-amber-100 px-2.5 py-2.5">
          <div className="col-span-2 flex items-start gap-2">
            <span className="w-7 h-7 shrink-0 rounded-lg bg-violet-100 text-violet-700 flex items-center justify-center"><CalendarDays className="w-4 h-4" /></span>
            <span className="min-w-0">
              <span className="block text-[8.5px] font-black text-stone-400 leading-none mb-0.5">تاريخ الحفل</span>
              <span className="block text-[11.5px] font-extrabold text-stone-800 leading-snug">{formatArabicDate(b.eventDate)}</span>
              <span className="num block text-[9px] font-bold text-violet-500 leading-snug">{toHijri(b.eventDate)}</span>
            </span>
            {b.eventTime && (
              <span className="num mr-auto shrink-0 inline-flex items-center gap-1 rounded-lg bg-teal-50 border border-teal-200 text-teal-800 text-[11px] font-black px-2 py-1 self-center"><Clock className="w-3.5 h-3.5" />{b.eventTime}</span>
            )}
          </div>
          <Row icon={MapPin} label="مكان الحفل" value={b.venue} tone="bg-emerald-100 text-emerald-700" />
          <Row icon={Mic2} label="زفة العروس" value={b.brideZaffa || 'غير محددة'} tone="bg-pink-100 text-pink-600" />
          <Row icon={Drum} label="زفة المعرس" value={b.groomZaffa || 'غير محددة'} tone="bg-fuchsia-100 text-fuchsia-600" />
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-7 h-7 shrink-0 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center"><BadgePercent className="w-4 h-4" /></span>
            <span className="min-w-0 w-full">
              <span className="flex items-center justify-between">
                <span className="text-[8.5px] font-black text-stone-400 leading-none">نسبة السداد</span>
                <span className="num text-[9.5px] font-black text-orange-700">{pct}%</span>
              </span>
              <span className="block h-2 rounded-full bg-stone-100 border border-stone-200 overflow-hidden mt-1"><span className="block h-full bg-gradient-to-l from-amber-400 to-orange-500 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} /></span>
            </span>
          </div>
        </div>

        {/* ---- money strip ---- */}
        <div className="grid grid-cols-3 gap-1.5 mt-2">
          {[
            { icon: Wallet, label: 'الإجمالي', v: b.totalAmount, cls: 'bg-amber-50 border-amber-200 text-amber-900' },
            { icon: Banknote, label: 'المدفوع', v: b.paidAmount, cls: 'bg-emerald-50 border-emerald-200 text-emerald-900' },
            { icon: PiggyBank, label: 'المتبقي', v: rem, cls: rem > 0 ? 'bg-rose-50 border-rose-200 text-rose-900' : 'bg-teal-50 border-teal-200 text-teal-900' },
          ].map((m, i) => (
            <div key={i} className={`rounded-2xl border-2 px-2 py-1.5 text-center ${m.cls}`}>
              <span className="flex items-center justify-center gap-1 text-[8.5px] font-black opacity-80"><m.icon className="w-3 h-3" />{m.label}</span>
              <span className="num block text-[11px] sm:text-[12px] font-black mt-0.5 truncate" dir="ltr">{OMR(m.v)}</span>
            </div>
          ))}
        </div>

        {/* ---- overdue banner + WhatsApp link (3-day rule) ---- */}
        {overdue && (
          <motion.a
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            href={waLinkFor(b)}
            target="_blank"
            rel="noreferrer"
            className="mt-2 flex items-center gap-2 rounded-2xl border-2 border-[#1fb855] bg-gradient-to-l from-[#25D366] to-[#128C7E] text-white px-3 py-2 shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all"
          >
            <span className="wa-pulse w-8 h-8 shrink-0 rounded-full bg-white/20 flex items-center justify-center">
              <MessageCircle className="w-5 h-5" fill="#fff" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[10px] font-black leading-tight">متأخر عن السداد أكثر من 3 أيام!</span>
              <span className="block text-[9px] font-bold text-white/90 leading-snug">اضغط لإرسال تذكير واتساب تلقائي للرقم +968 — المتبقي {OMR(rem)}</span>
            </span>
            <span className="num text-[9px] font-black bg-black/25 rounded-lg px-2 py-1 shrink-0" dir="ltr">+968</span>
          </motion.a>
        )}

        {/* ---- expandable notes ---- */}
        {b.notes && (
          <>
            <button onClick={() => setExpanded((v) => !v)} className="mt-2 inline-flex items-center gap-1.5 text-[9.5px] font-black text-stone-500 hover:text-orange-700">
              <StickyNote className="w-3.5 h-3.5" /> ملاحظات <ChevronDown className={`w-3.5 h-3.5 transition-transform ${expanded ? 'rotate-180' : ''}`} />
            </button>
            <AnimatePresence>
              {expanded && (
                <motion.p initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden text-[10.5px] font-bold text-stone-600 bg-amber-50/60 border border-amber-100 rounded-xl px-3 py-2 mt-1 leading-relaxed">
                  {b.notes}
                </motion.p>
              )}
            </AnimatePresence>
          </>
        )}

        {/* ---- action row ---- */}
        <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-dashed border-amber-200">
          <span className="text-[8.5px] font-black text-stone-400 ml-1 hidden xs:inline">
            {dLeft >= 0 ? (dLeft === 0 ? 'الحفل الليلة!' : `باقي ${dLeft} يوم`) : 'انتهى الحفل'}
          </span>
          <div className="flex items-center gap-1.5 mr-auto">
            {rem > 0.001 && (
              <button onClick={() => onMarkPaid(b)} title="تسجيل دفعة كاملة — المبلغ صار 0" className="w-8 h-8 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-700 flex items-center justify-center hover:bg-emerald-200 transition-all">
                <CheckCircle2 className="w-4.5 h-4.5" />
              </button>
            )}
            {rem <= 0.001 && <span className="w-8 h-8 rounded-xl bg-teal-50 border border-teal-200 text-teal-600 flex items-center justify-center"><CheckCircle2 className="w-4.5 h-4.5" /></span>}
            <button onClick={() => onPrint(b)} title="طباعة إيصال الحجز" className="w-8 h-8 rounded-xl bg-violet-100 border border-violet-300 text-violet-700 flex items-center justify-center hover:bg-violet-200 transition-all">
              <Printer className="w-4 h-4" />
            </button>
            <button onClick={() => onEdit(b)} title="تعديل الحجز" className="w-8 h-8 rounded-xl bg-sky-100 border border-sky-300 text-sky-700 flex items-center justify-center hover:bg-sky-200 transition-all">
              <PencilLine className="w-4 h-4" />
            </button>
            <button onClick={() => onDelete(b)} title="حذف الحجز" className="w-8 h-8 rounded-xl bg-rose-100 border border-rose-300 text-rose-600 flex items-center justify-center hover:bg-rose-200 hover:text-rose-800 transition-all">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.article>
  );
}
