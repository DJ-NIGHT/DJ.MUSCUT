import { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  User, Phone, CalendarDays, Clock, MapPin, Mic2, Drum, Wallet, Banknote, PiggyBank,
  Save, Eraser, CheckCircle2, PencilLine, Music4, PartyPopper, StickyNote,
  Users, Sparkles, BadgePercent, Receipt, PhoneCall,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { Booking, Category } from '../lib/types';
import { OMR, paidPercent, remaining, todayISO, waLinkFor } from '../lib/utils';

/* ---------- field palette (fully colorful, light background) ---------- */
interface Palette { wrap: string; iconBox: string; ring: string; chip: string }
const P: Record<string, Palette> = {
  amber: { wrap: 'bg-amber-50 border-amber-200', iconBox: 'bg-gradient-to-br from-amber-400 to-orange-500 text-white', ring: 'focus:border-amber-400', chip: 'text-amber-700' },
  sky: { wrap: 'bg-sky-50 border-sky-200', iconBox: 'bg-gradient-to-br from-sky-400 to-blue-600 text-white', ring: 'focus:border-sky-400', chip: 'text-sky-700' },
  violet: { wrap: 'bg-violet-50 border-violet-200', iconBox: 'bg-gradient-to-br from-violet-400 to-purple-600 text-white', ring: 'focus:border-violet-400', chip: 'text-violet-700' },
  emerald: { wrap: 'bg-emerald-50 border-emerald-200', iconBox: 'bg-gradient-to-br from-emerald-400 to-green-600 text-white', ring: 'focus:border-emerald-400', chip: 'text-emerald-700' },
  pink: { wrap: 'bg-pink-50 border-pink-200', iconBox: 'bg-gradient-to-br from-pink-400 to-rose-500 text-white', ring: 'focus:border-pink-400', chip: 'text-pink-700' },
  fuchsia: { wrap: 'bg-fuchsia-50 border-fuchsia-200', iconBox: 'bg-gradient-to-br from-fuchsia-400 to-purple-600 text-white', ring: 'focus:border-fuchsia-400', chip: 'text-fuchsia-700' },
  teal: { wrap: 'bg-teal-50 border-teal-200', iconBox: 'bg-gradient-to-br from-teal-400 to-emerald-600 text-white', ring: 'focus:border-teal-400', chip: 'text-teal-700' },
  orange: { wrap: 'bg-orange-50 border-orange-200', iconBox: 'bg-gradient-to-br from-orange-400 to-red-500 text-white', ring: 'focus:border-orange-400', chip: 'text-orange-700' },
  rose: { wrap: 'bg-rose-50 border-rose-200', iconBox: 'bg-gradient-to-br from-rose-400 to-red-600 text-white', ring: 'focus:border-rose-400', chip: 'text-rose-700' },
};

interface FieldProps {
  label: string;
  icon: LucideIcon;
  palette: Palette;
  error?: string;
  hint?: string;
  span?: string;
  children: React.ReactNode;
}

/** A fully-colored labeled field with a gradient icon tile. */
function Field({ label, icon: Icon, palette, error, hint, span = '', children }: FieldProps) {
  return (
    <div className={span}>
      <label className={`flex items-center gap-1.5 mb-1.5 text-[11.5px] font-black ${palette.chip}`}>
        <Icon className="w-3.5 h-3.5" />
        {label}
      </label>
      <div className={`field flex items-center gap-2 rounded-2xl border-2 px-2.5 transition-all duration-200 ${palette.wrap} ${error ? '!border-rose-400 !bg-rose-50' : ''}`}>
        <span className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center shadow-sm ${palette.iconBox}`}>
          <Icon className="w-[18px] h-[18px]" strokeWidth={2.1} />
        </span>
        {children}
      </div>
      {error ? (
        <p className="mt-1 text-[10.5px] font-extrabold text-rose-600 flex items-center gap-1">● {error}</p>
      ) : hint ? (
        <p className="mt-1 text-[10px] font-bold text-stone-400">{hint}</p>
      ) : null}
    </div>
  );
}

const inputCls =
  'w-full bg-transparent outline-none py-2.5 text-[13px] sm:text-[13.5px] font-bold text-stone-800 placeholder:text-stone-400 placeholder:font-semibold min-w-0';

export interface BookingFormHandle { reset: () => void }

interface Props {
  editing: Booking | null;
  onSave: (data: Omit<Booking, 'id' | 'createdAt'>, existingId?: string) => void;
  savedSlip: Booking | null;
  onDismissSlip: () => void;
  onEditSlip: (b: Booking) => void;
}

const CATEGORIES: { value: Category; emoji: string }[] = [
  { value: 'زفاف', emoji: '💍' }, { value: 'خطوبة', emoji: '💑' }, { value: 'تخرج', emoji: '🎓' },
  { value: 'عقيقة', emoji: '👶' }, { value: 'حفل شركة', emoji: '🏢' }, { value: 'ذكرى سنوية', emoji: '🎊' },
];

const EMPTY = {
  ownerName: '', ownerPhone: '', eventDate: todayISO(), eventTime: '21:00', venue: '',
  brideZaffa: '', groomZaffa: '', totalAmount: '', paidAmount: '', category: 'زفاف' as Category, notes: '',
};

export default function BookingForm({ editing, onSave, savedSlip, onDismissSlip, onEditSlip }: Props) {
  const [f, setF] = useState(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [justSaved, setJustSaved] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  const isEdit = !!editing;

  useEffect(() => {
    if (editing) {
      setF({
        ownerName: editing.ownerName, ownerPhone: editing.ownerPhone, eventDate: editing.eventDate,
        eventTime: editing.eventTime, venue: editing.venue, brideZaffa: editing.brideZaffa,
        groomZaffa: editing.groomZaffa, totalAmount: String(editing.totalAmount), paidAmount: String(editing.paidAmount),
        category: editing.category, notes: editing.notes,
      });
      setErrors({});
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [editing]);

  const total = parseFloat(f.totalAmount) || 0;
  const paid = parseFloat(f.paidAmount) || 0;
  const rem = Math.max(0, Math.round((total - paid) * 1000) / 1000);
  const pct = paidPercent(total, paid);
  const overpaid = paid > total && total > 0;

  const set = (k: keyof typeof EMPTY) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setF({ ...f, [k]: e.target.value });
    if (errors[k]) setErrors({ ...errors, [k]: '' });
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!f.ownerName.trim() || f.ownerName.trim().length < 3) e.ownerName = 'أدخل اسم صاحب الحفل كاملًا (3 أحرف فأكثر)';
    if (!f.ownerPhone.trim()) e.ownerPhone = 'رقم هاتف صاحب الحفل مطلوب';
    else if (!/^(\+?968)?[79]\d{7}$/.test(f.ownerPhone.replace(/[\s-]/g, ''))) e.ownerPhone = 'رقم عُماني غير صالح — 8 أرقام تبدأ بـ 7 أو 9 (مثال: 9123 4567)';
    if (!f.eventDate) e.eventDate = 'تاريخ الحفل مطلوب';
    if (!f.venue.trim() || f.venue.trim().length < 3) e.venue = 'أدخل مكان الحفل';
    if (!f.totalAmount || isNaN(parseFloat(f.totalAmount)) || parseFloat(f.totalAmount) <= 0) e.totalAmount = 'أدخل المبلغ الإجمالي أكبر من صفر';
    if (f.paidAmount !== '' && (isNaN(parseFloat(f.paidAmount)) || parseFloat(f.paidAmount) < 0)) e.paidAmount = 'مبلغ غير صالح';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = () => {
    if (!validate()) return;
    onSave(
      {
        ownerName: f.ownerName.trim(),
        ownerPhone: f.ownerPhone.trim(),
        eventDate: f.eventDate,
        eventTime: f.eventTime,
        venue: f.venue.trim(),
        brideZaffa: f.brideZaffa.trim(),
        groomZaffa: f.groomZaffa.trim(),
        totalAmount: Math.round(parseFloat(f.totalAmount) * 1000) / 1000,
        paidAmount: Math.round((parseFloat(f.paidAmount) || 0) * 1000) / 1000,
        category: f.category,
        notes: f.notes.trim(),
      },
      editing?.id
    );
    if (!editing) {
      setF({ ...EMPTY, eventDate: todayISO() });
      setErrors({});
    }
    setJustSaved(true);
    window.setTimeout(() => setJustSaved(false), 2400);
  };

  const clear = () => {
    setF({ ...EMPTY, eventDate: todayISO() });
    setErrors({});
  };

  /* ============ SAVED SLIP VIEW (after pressing حفظ الحجز) ============ */
  if (savedSlip) {
    const b = savedSlip;
    const brem = remaining(b.totalAmount, b.paidAmount);
    const bpct = paidPercent(b.totalAmount, b.paidAmount);
    const paidFull = brem <= 0.001;
    return (
      <div ref={formRef} id="new-booking" className="max-w-7xl mx-auto px-4 sm:px-6 py-10 scroll-mt-24">
        <motion.div
          key={b.id}
          initial={{ opacity: 0, scale: 0.9, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 220, damping: 22 }}
          className="relative max-w-2xl mx-auto rounded-[26px] border-2 border-amber-300 bg-white shadow-[0_25px_70px_-25px_rgba(217,119,6,0.45)] overflow-hidden"
        >
          {/* slip perforated header */}
          <div className="relative bg-gradient-to-l from-emerald-500 via-green-600 to-teal-600 text-white px-6 pt-5 pb-6 text-center">
            <motion.div initial={{ scale: 0, rotate: -30 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: 'spring', stiffness: 260, damping: 15, delay: 0.15 }}>
              <CheckCircle2 className="w-14 h-14 mx-auto drop-shadow" strokeWidth={1.6} />
            </motion.div>
            <h3 className="font-lalezar text-2xl mt-1.5">تم حفظ الحجز بنجاح!</h3>
            <p className="text-[11px] font-bold text-emerald-50/90 mt-0.5">رقم الحجز: <span className="num">#{b.id.slice(0, 8).toUpperCase()}</span> — أُضيف إلى سجلّك وظهرت رموز الحقول كاملة</p>
            {/* punched holes */}
            <span className="absolute -bottom-3.5 right-8 w-7 h-7 rounded-full bg-[#fdf6ea] border-2 border-amber-200" />
            <span className="absolute -bottom-3.5 left-8 w-7 h-7 rounded-full bg-[#fdf6ea] border-2 border-amber-200" />
          </div>

          <div className="px-5 sm:px-7 pt-6 pb-6">
            {/* compact chip rows WITH field icons */}
            <div className="grid sm:grid-cols-2 gap-2">
              <SlipChip icon={User} label="صاحب الحفل" value={b.ownerName} tone="amber" />
              <SlipChip icon={Phone} label="هاتف صاحب الحفل" value={b.ownerPhone} tone="sky" dir="ltr" />
              <SlipChip icon={CalendarDays} label="تاريخ الحفل" value={`${b.eventDate}${b.eventTime ? ' — ' + b.eventTime : ''}`} tone="violet" dir="ltr" />
              <SlipChip icon={MapPin} label="مكان الحفل" value={b.venue} tone="emerald" />
              <SlipChip icon={Mic2} label="زفة العروس" value={b.brideZaffa || '—'} tone="pink" />
              <SlipChip icon={Drum} label="زفة المعرس" value={b.groomZaffa || '—'} tone="fuchsia" />
            </div>

            {/* money band */}
            <div className="mt-3 grid grid-cols-3 gap-2">
              <MoneyBox label="الإجمالي" value={b.totalAmount} cls="bg-amber-50 border-amber-300 text-amber-800" />
              <MoneyBox label="المدفوع" value={b.paidAmount} cls="bg-emerald-50 border-emerald-300 text-emerald-800" />
              <MoneyBox label="المتبقي" value={brem} cls="bg-rose-50 border-rose-300 text-rose-800" />
            </div>

            {/* payment progress */}
            <div className="mt-3">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10.5px] font-black text-stone-500 flex items-center gap-1"><BadgePercent className="w-3.5 h-3.5" /> نسبة السداد</span>
                <span className="num text-[11px] font-black text-stone-700">{bpct}%</span>
              </div>
              <div className="h-3.5 rounded-full bg-stone-100 border border-stone-200 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${bpct}%` }}
                  transition={{ duration: 0.9, ease: 'easeOut', delay: 0.3 }}
                  className={`h-full rounded-full bg-gradient-to-l ${paidFull ? 'from-emerald-400 to-green-600' : 'from-amber-400 to-orange-500'}`}
                />
              </div>
            </div>

            <div className="mt-4 flex flex-col sm:flex-row gap-2">
              <a href={waLinkFor(b, `السلام عليكم ${b.ownerName} 🌹\nتم تأكيد حجز حفلكم (${b.category}) بتاريخ ${b.eventDate} في ${b.venue}.\nالإجمالي: ${OMR(b.totalAmount)} — المدفوع: ${OMR(b.paidAmount)} — المتبقي: ${OMR(brem)}.\nديجي مسقط 🎧`)} target="_blank" rel="noreferrer"
                 className="flex-1 inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-[12px] font-black text-white bg-[#25D366] hover:bg-[#1fb855] shadow-lg shadow-green-500/25 transition-all">
                <PhoneCall className="w-4.5 h-4.5" /> إرسال تأكيد عبر واتساب +968
              </a>
              <div className="flex gap-2">
                <button onClick={() => onEditSlip(b)} className="inline-flex items-center justify-center gap-1.5 rounded-2xl px-4 py-3 text-[12px] font-black text-violet-800 bg-violet-100 border-2 border-violet-300 hover:bg-violet-200 transition-all">
                  <PencilLine className="w-4 h-4" /> تعديل
                </button>
                <button onClick={onDismissSlip} className="inline-flex items-center justify-center gap-1.5 rounded-2xl px-4 py-3 text-[12px] font-black text-amber-900 bg-amber-100 border-2 border-amber-300 hover:bg-amber-200 transition-all">
                  <Receipt className="w-4 h-4" /> حجز آخر
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  /* ============ FORM VIEW ============ */
  return (
    <div ref={formRef} id="new-booking" className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10 scroll-mt-24">
      {/* section header */}
      <div className="flex items-center gap-3 mb-4">
        <span className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 via-orange-500 to-rose-600 flex items-center justify-center shadow-lg shadow-orange-500/30 text-white">
          <Music4 className="w-6 h-6" />
        </span>
        <div>
          <h2 className="font-lalezar text-[22px] sm:text-2xl text-stone-900 leading-none">{isEdit ? 'تعديل بيانات الحجز' : 'حجز حفل جديد'}</h2>
          <p className="text-[10.5px] sm:text-[11px] font-bold text-stone-500 mt-1">{isEdit ? 'عدّل أي حقل ثم اضغط «حفظ التعديلات»' : 'كل حقل بأيقونته ومكانه — البيانات المُدخلة تنضغط وتُعرض برموزها عند الحفظ'}</p>
        </div>
        {isEdit && <span className="mr-auto rounded-full bg-violet-100 border border-violet-300 text-violet-800 text-[10.5px] font-black px-3 py-1.5 num">وضع التعديل #{editing?.id.slice(0, 6).toUpperCase()}</span>}
      </div>

      <div className="rounded-[26px] border-2 border-amber-200 bg-gradient-to-br from-[#FFFDF6] via-[#FFF9EC] to-[#FFF3E2] shadow-[0_20px_55px_-25px_rgba(180,120,30,0.4)] p-4 sm:p-6">
        {/* category pills */}
        <div className="flex flex-wrap items-center gap-1.5 mb-4 pb-4 border-b-2 border-dashed border-amber-200">
          <span className="text-[11px] font-black text-stone-500 flex items-center gap-1.5 ml-1"><PartyPopper className="w-4 h-4 text-orange-500" /> نوع الحفل:</span>
          {CATEGORIES.map((c) => (
            <button
              key={c.value}
              onClick={() => setF({ ...f, category: c.value })}
              className={`rounded-full px-3 py-1.5 text-[11px] sm:text-[11.5px] font-black border-2 transition-all ${
                f.category === c.value
                  ? 'bg-gradient-to-l from-amber-500 to-orange-600 text-white border-orange-700 shadow-md scale-105'
                  : 'bg-white text-stone-600 border-amber-200 hover:border-amber-400 hover:text-orange-800'
              }`}
            >
              {c.emoji} {c.value}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-x-4 gap-y-4">
          {/* صاحب الحفل */}
          <Field label="صاحب الحفل" icon={User} palette={P.amber} error={errors.ownerName} span="xl:col-span-2">
            <input className={inputCls} placeholder="مثال: سعيد بن راشد البلوشي" value={f.ownerName} onChange={set('ownerName')} />
          </Field>

          {/* هاتف صاحب الحفل */}
          <Field label="هاتف صاحب الحفل (واتساب +968)" icon={Phone} palette={P.sky} error={errors.ownerPhone} span="xl:col-span-2">
            <span className="shrink-0 text-[11px] font-black text-sky-800 bg-sky-100 border border-sky-200 rounded-lg px-2 py-1.5 num select-none" dir="ltr">🇴🇲 +968</span>
            <input className={`${inputCls} num text-left`} dir="ltr" inputMode="tel" placeholder="9123 4567" value={f.ownerPhone} onChange={set('ownerPhone')} />
          </Field>

          {/* تاريخ الحفل */}
          <Field label="تاريخ الحفل" icon={CalendarDays} palette={P.violet} error={errors.eventDate}>
            <input type="date" className={`${inputCls} num`} value={f.eventDate} onChange={set('eventDate')} />
          </Field>

          {/* وقت الحفل */}
          <Field label="وقت الحفل" icon={Clock} palette={P.teal}>
            <input type="time" className={`${inputCls} num`} value={f.eventTime} onChange={set('eventTime')} />
          </Field>

          {/* مكان الحفل */}
          <Field label="مكان الحفل" icon={MapPin} palette={P.emerald} error={errors.venue} span="md:col-span-2">
            <input className={inputCls} placeholder="مثال: قاعة الأريانة – القرم" value={f.venue} onChange={set('venue')} list="venues" />
            <datalist id="venues">
              {['قاعة الأريانة – القرم', 'قصر تلال مسقط – بوشر', 'قاعة المروج الملكية – السيب', 'قاعة اللؤلؤة الذهبية – الغبرة', 'قاعة السراب الذهبية – بركاء', 'قاعة الرمال الذهبية – مطرح', 'حديقة النادي الأهلي – روي'].map((v) => <option key={v} value={v} />)}
            </datalist>
          </Field>

          {/* زفة العروس */}
          <Field label="اسم زفة العروس" icon={Mic2} palette={P.pink} span="md:col-span-2" hint="اسم الزفة والفنان — مثال: زفة «يا هلا بالمعرس» بصوت فهد العبدالمحسن">
            <input className={inputCls} placeholder="زفة «…» بصوت …" value={f.brideZaffa} onChange={set('brideZaffa')} />
          </Field>

          {/* زفة المعرس */}
          <Field label="زفة المعرس" icon={Drum} palette={P.fuchsia} span="md:col-span-2" hint="زفة دخول العريس — يمكن كتابة الفنان أو الطابع الشعبي">
            <input className={inputCls} placeholder="مثال: زفة «هلا هلا» مع مزمار بلوشي" value={f.groomZaffa} onChange={set('groomZaffa')} />
          </Field>

          {/* المبلغ الإجمالي */}
          <Field label="المبلغ الإجمالي (ر.ع)" icon={Wallet} palette={P.orange} error={errors.totalAmount}>
            <input type="number" min="0" step="0.001" inputMode="decimal" className={`${inputCls} num`} placeholder="0.000" value={f.totalAmount} onChange={set('totalAmount')} />
          </Field>

          {/* المبلغ المدفوع */}
          <Field label="المبلغ المدفوع (ر.ع)" icon={Banknote} palette={P.emerald}>
            <input type="number" min="0" step="0.001" inputMode="decimal" className={`${inputCls} num`} placeholder="0.000" value={f.paidAmount} onChange={set('paidAmount')} />
          </Field>

          {/* المبلغ المتبقي — تلقائي */}
          <Field label="المبلغ المتبقي (ر.ع) — تلقائي" icon={PiggyBank} palette={overpaid ? P.rose : P.amber}>
            <input readOnly className={`${inputCls} num cursor-default ${overpaid ? 'text-rose-700' : 'text-amber-800'} font-black`} value={rem.toFixed(3)} tabIndex={-1} />
          </Field>

          {/* نسبة السداد — شريط */}
          <div className="rounded-2xl border-2 border-teal-200 bg-teal-50 px-3 py-2 flex flex-col justify-center">
            <div className="flex items-center justify-between">
              <span className="text-[10.5px] font-black text-teal-800 flex items-center gap-1.5"><BadgePercent className="w-4 h-4" /> نسبة السداد</span>
              <span className="num text-[12px] font-black text-teal-900">{pct}%</span>
            </div>
            <div className="h-2.5 rounded-full bg-white border border-teal-200 overflow-hidden mt-1.5">
              <div className="h-full bg-gradient-to-l from-teal-400 to-emerald-600 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
            </div>
            {overpaid && <p className="text-[9.5px] font-extrabold text-rose-600 mt-1">تنبيه: المدفوع أكبر من الإجمالي!</p>}
          </div>

          {/* ملاحظات */}
          <div className="md:col-span-2 xl:col-span-4">
            <label className="flex items-center gap-1.5 mb-1.5 text-[11.5px] font-black text-stone-500">
              <StickyNote className="w-3.5 h-3.5" /> ملاحظات إضافية (اختياري)
            </label>
            <textarea rows={2} className="w-full rounded-2xl border-2 border-stone-200 bg-white px-4 py-2.5 outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-200/50 text-[12.5px] font-bold text-stone-800 placeholder:text-stone-400 resize-none transition-all" placeholder="طلبات خاصة، توقيت الدخول، تجهيزات إضافية…" value={f.notes} onChange={set('notes')} />
          </div>
        </div>

        {/* ===== SAVE BAR ===== */}
        <div className="mt-5 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
          <button
            onClick={submit}
            className={`shimmer relative overflow-hidden flex-1 inline-flex items-center justify-center gap-2.5 rounded-2xl px-6 py-4 font-lalezar text-[17px] sm:text-lg text-white border transition-all hover:-translate-y-0.5 ${
              justSaved
                ? 'bg-emerald-600 border-emerald-700 shadow-emerald-600/40 shadow-xl'
                : 'bg-gradient-to-l from-amber-500 via-orange-600 to-rose-600 border-orange-800/30 shadow-xl shadow-orange-600/30 hover:shadow-2xl'
            }`}
          >
            {justSaved ? <><CheckCircle2 className="w-6 h-6" /> تم الحفظ بنجاح!</> : <><Save className="w-6 h-6" /> {isEdit ? 'حفظ التعديلات' : 'حفظ الحجز'}</>}
          </button>
          <button onClick={clear} className="inline-flex items-center justify-center gap-2 rounded-2xl px-6 py-4 text-[13px] font-black text-stone-600 bg-white border-2 border-stone-200 hover:border-rose-300 hover:text-rose-700 transition-all">
            <Eraser className="w-5 h-5" /> مسح الحقول
          </button>
        </div>

        {/* live summary mini-bar */}
        <div className="mt-3 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 rounded-2xl bg-stone-900 text-amber-100 px-4 py-2 text-[10.5px] sm:text-[11px] font-bold">
          <span className="flex items-center gap-1.5"><Users className="w-3.5 h-3.5 text-amber-400" /> {f.ownerName || 'صاحب الحفل…'}</span>
          <span className="num flex items-center gap-1.5" dir="ltr"><Phone className="w-3.5 h-3.5 text-sky-400" /> {f.ownerPhone || '968…'}</span>
          <span className="num flex items-center gap-1.5"><CalendarDays className="w-3.5 h-3.5 text-violet-400" /> {f.eventDate || '—'} {f.eventTime}</span>
          <span className="num flex items-center gap-1.5"><Wallet className="w-3.5 h-3.5 text-orange-400" /> المتبقي: {OMR(rem)}</span>
          <span className="flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5 text-fuchsia-400" /> {f.category}</span>
        </div>
      </div>
    </div>
  );
}

/* ---------- slip sub-components ---------- */
const TONE: Record<string, string> = {
  amber: 'bg-amber-50 border-amber-200 text-amber-800',
  sky: 'bg-sky-50 border-sky-200 text-sky-800',
  violet: 'bg-violet-50 border-violet-200 text-violet-800',
  emerald: 'bg-emerald-50 border-emerald-200 text-emerald-800',
  pink: 'bg-pink-50 border-pink-200 text-pink-800',
  fuchsia: 'bg-fuchsia-50 border-fuchsia-200 text-fuchsia-800',
};
const TONE_ICON: Record<string, string> = {
  amber: 'from-amber-400 to-orange-500', sky: 'from-sky-400 to-blue-600', violet: 'from-violet-400 to-purple-600',
  emerald: 'from-emerald-400 to-green-600', pink: 'from-pink-400 to-rose-500', fuchsia: 'from-fuchsia-400 to-purple-600',
};

function SlipChip({ icon: Icon, label, value, tone, dir }: { icon: LucideIcon; label: string; value: string; tone: string; dir?: 'ltr' | 'rtl' }) {
  return (
    <div className={`flex items-center gap-2 rounded-2xl border-2 px-2.5 py-2 ${TONE[tone]}`}>
      <span className={`w-8 h-8 shrink-0 rounded-lg bg-gradient-to-br ${TONE_ICON[tone]} text-white flex items-center justify-center shadow-sm`}>
        <Icon className="w-4 h-4" strokeWidth={2.2} />
      </span>
      <span className="min-w-0">
        <span className="block text-[9px] font-black opacity-70">{label}</span>
        <span className="block text-[11.5px] font-extrabold truncate" dir={dir}>{value}</span>
      </span>
    </div>
  );
}

function MoneyBox({ label, value, cls }: { label: string; value: number; cls: string }) {
  return (
    <div className={`rounded-2xl border-2 text-center py-2 px-1 ${cls}`}>
      <p className="text-[9.5px] font-black opacity-80">{label}</p>
      <p className="num text-[13px] sm:text-sm font-black mt-0.5 truncate" dir="ltr">{OMR(value)}</p>
    </div>
  );
}
