import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Search, SlidersHorizontal, ArrowDownUp, FileSpreadsheet, FileJson, Trash2, Inbox, ListMusic, X,
} from 'lucide-react';
import type { Booking, PayStatus } from '../lib/types';
import { daysUntil, downloadFile, isPaymentOverdue, remaining, toCSV } from '../lib/utils';
import BookingCard from './BookingCard';

type SortKey = 'eventDate' | 'createdAt' | 'remaining' | 'totalAmount' | 'ownerName';
type PayFilter = 'all' | PayStatus;
type DateFilter = 'all' | 'upcoming' | 'past' | 'thisMonth';

const PAGE = 6;

interface Props {
  bookings: Booking[];
  onEdit: (b: Booking) => void;
  onDelete: (b: Booking) => void;
  onMarkPaid: (b: Booking) => void;
  onPrint: (b: Booking) => void;
  onClearAll: () => void;
}

export default function BookingList({ bookings, onEdit, onDelete, onMarkPaid, onPrint, onClearAll }: Props) {
  const [query, setQuery] = useState('');
  const [payFilter, setPayFilter] = useState<PayFilter>('all');
  const [dateFilter, setDateFilter] = useState<DateFilter>('all');
  const [sort, setSort] = useState<SortKey>('eventDate');
  const [page, setPage] = useState(1);

  useEffect(() => { setPage(1); }, [query, payFilter, dateFilter, sort, bookings.length]);

  const filtered = useMemo(() => {
    let arr = [...bookings];

    if (query.trim()) {
      const q = query.trim().toLowerCase();
      arr = arr.filter((b) =>
        [b.ownerName, b.ownerPhone, b.venue, b.brideZaffa, b.groomZaffa, b.category, b.notes, b.eventDate]
          .join(' ')
          .toLowerCase()
          .includes(q)
      );
    }

    if (payFilter !== 'all') {
      arr = arr.filter((b) => {
        const rem = remaining(b.totalAmount, b.paidAmount);
        if (payFilter === 'paid') return rem <= 0.001;
        if (payFilter === 'partial') return rem > 0.001 && b.paidAmount > 0;
        return rem > 0.001 && b.paidAmount <= 0;
      });
    }

    if (dateFilter !== 'all') {
      arr = arr.filter((b) => {
        const d = daysUntil(b.eventDate);
        if (dateFilter === 'upcoming') return d >= 0;
        if (dateFilter === 'past') return d < 0;
        const now = new Date();
        const ev = new Date(b.eventDate + 'T00:00:00');
        return ev.getMonth() === now.getMonth() && ev.getFullYear() === now.getFullYear();
      });
    }

    arr.sort((a, b) => {
      switch (sort) {
        case 'createdAt': return +new Date(b.createdAt) - +new Date(a.createdAt);
        case 'remaining': return remaining(b.totalAmount, b.paidAmount) - remaining(a.totalAmount, a.paidAmount);
        case 'totalAmount': return b.totalAmount - a.totalAmount;
        case 'ownerName': return a.ownerName.localeCompare(b.ownerName, 'ar');
        case 'eventDate':
        default: {
          const da = daysUntil(a.eventDate);
          const db = daysUntil(b.eventDate);
          // upcoming first (soonest), then past (most recent)
          if (da >= 0 && db >= 0) return da - db;
          if (da < 0 && db < 0) return db - da;
          return da >= 0 ? -1 : 1;
        }
      }
    });
    return arr;
  }, [bookings, query, payFilter, dateFilter, sort]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE));
  const pageItems = filtered.slice((page - 1) * PAGE, page * PAGE);
  const overdueCount = filtered.filter(isPaymentOverdue).length;

  const exportCSV = () => downloadFile(`ديجي-مسقط-حجوزات-${new Date().toISOString().slice(0, 10)}.csv`, toCSV(filtered), 'text/csv;charset=utf-8');
  const exportJSON = () => downloadFile(`ديجي-مسقط-نسخة-احتياطية-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(bookings, null, 2), 'application/json;charset=utf-8');

  return (
    <section id="bookings" className="max-w-7xl mx-auto px-4 sm:px-6 pb-4 scroll-mt-24">
      {/* section header */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <span className="w-11 h-11 rounded-2xl bg-gradient-to-br from-violet-500 via-purple-600 to-fuchsia-600 flex items-center justify-center shadow-lg shadow-purple-500/30 text-white">
          <ListMusic className="w-6 h-6" />
        </span>
        <div>
          <h2 className="font-lalezar text-[22px] sm:text-2xl text-stone-900 leading-none">سجلّ الحجوزات <span className="num text-orange-600">({filtered.length})</span></h2>
          <p className="text-[10.5px] sm:text-[11px] font-bold text-stone-500 mt-1">
            {overdueCount > 0 ? <span className="text-rose-600 font-black">{overdueCount} حجز متأخر عن السداد +3 أيام — يسعك التذكير بواتساب!</span> : 'مقسّمة ومنظمة وقابلة للتعديل والحذف في أي وقت'}
          </p>
        </div>
        <div className="mr-auto flex items-center gap-1.5">
          <button onClick={exportCSV} title="تصدير Excel / CSV" className="inline-flex items-center gap-1.5 rounded-xl border-2 border-emerald-300 bg-emerald-50 text-emerald-800 px-2.5 sm:px-3 py-2 text-[10.5px] font-black hover:bg-emerald-100 transition-colors">
            <FileSpreadsheet className="w-4 h-4" /><span className="hidden sm:inline">إكسل</span>
          </button>
          <button onClick={exportJSON} title="نسخة احتياطية JSON" className="inline-flex items-center gap-1.5 rounded-xl border-2 border-sky-300 bg-sky-50 text-sky-800 px-2.5 sm:px-3 py-2 text-[10.5px] font-black hover:bg-sky-100 transition-colors">
            <FileJson className="w-4 h-4" /><span className="hidden sm:inline">نسخة احتياطية</span>
          </button>
          {bookings.length > 0 && (
            <button onClick={onClearAll} title="مسح كل الحجوزات" className="inline-flex items-center gap-1.5 rounded-xl border-2 border-rose-300 bg-rose-50 text-rose-700 px-2.5 sm:px-3 py-2 text-[10.5px] font-black hover:bg-rose-100 transition-colors">
              <Trash2 className="w-4 h-4" /><span className="hidden sm:inline">مسح الكل</span>
            </button>
          )}
        </div>
      </div>

      {/* ---- toolbar: search + filters + sort ---- */}
      <div className="rounded-3xl border-2 border-amber-200 bg-white/80 backdrop-blur p-3 flex flex-col lg:flex-row lg:items-center gap-2.5 shadow-sm">
        <div className="relative flex-1 min-w-0">
          <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-amber-600 pointer-events-none" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث باسم صاحب الحفل، الهاتف، المكان، الزفة…"
            className="w-full h-11 rounded-2xl border-2 border-amber-100 bg-amber-50/50 pr-11 pl-10 text-[13px] font-bold text-stone-800 placeholder:text-stone-400 outline-none focus:border-amber-400 focus:bg-white transition-all"
          />
          {query && (
            <button onClick={() => setQuery('')} className="absolute left-3 top-1/2 -translate-y-1/2 p-1 rounded-lg hover:bg-stone-100 text-stone-400"><X className="w-4 h-4" /></button>
          )}
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 lg:pb-0">
          {/* pay filter */}
          <div className="flex items-center gap-1 rounded-2xl border-2 border-stone-100 bg-stone-50 p-1 shrink-0">
            <SlidersHorizontal className="w-4 h-4 text-stone-400 mx-1 hidden sm:block" />
            {([['all', 'الكل'], ['paid', 'مدفوع'], ['partial', 'جزئي'], ['unpaid', 'غير مدفوع']] as [PayFilter, string][]).map(([v, l]) => (
              <button key={v} onClick={() => setPayFilter(v)} className={`rounded-xl px-2.5 sm:px-3 py-1.5 text-[10.5px] font-black transition-all whitespace-nowrap ${payFilter === v ? 'bg-gradient-to-l from-amber-500 to-orange-600 text-white shadow' : 'text-stone-500 hover:text-stone-800'}`}>{l}</button>
            ))}
          </div>

          {/* date filter */}
          <div className="flex items-center gap-1 rounded-2xl border-2 border-stone-100 bg-stone-50 p-1 shrink-0">
            {([['all', 'التواريخ'], ['upcoming', 'القادمة'], ['thisMonth', 'هذا الشهر'], ['past', 'المنتهية']] as [DateFilter, string][]).map(([v, l]) => (
              <button key={v} onClick={() => setDateFilter(v)} className={`rounded-xl px-2.5 sm:px-3 py-1.5 text-[10.5px] font-black transition-all whitespace-nowrap ${dateFilter === v ? 'bg-gradient-to-l from-violet-500 to-purple-600 text-white shadow' : 'text-stone-500 hover:text-stone-800'}`}>{l}</button>
            ))}
          </div>

          {/* sort */}
          <label className="flex items-center gap-1.5 rounded-2xl border-2 border-stone-100 bg-stone-50 px-2.5 py-1.5 shrink-0">
            <ArrowDownUp className="w-4 h-4 text-stone-400" />
            <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} className="bg-transparent outline-none text-[10.5px] font-black text-stone-600 cursor-pointer">
              <option value="eventDate">الأقرب موعدًا</option>
              <option value="createdAt">الأحدث إنشاءً</option>
              <option value="remaining">الأعلى متبقيًا</option>
              <option value="totalAmount">الأعلى مبلغًا</option>
              <option value="ownerName">أبجديًا (الاسم)</option>
            </select>
          </label>
        </div>
      </div>

      {/* ---- cards grid ---- */}
      {pageItems.length > 0 ? (
        <>
          <motion.div layout className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mt-4 items-start">
            <AnimatePresence mode="popLayout">
              {pageItems.map((b) => (
                <BookingCard key={b.id} booking={b} onEdit={onEdit} onDelete={onDelete} onMarkPaid={onMarkPaid} onPrint={onPrint} />
              ))}
            </AnimatePresence>
          </motion.div>

          {/* pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-1.5 mt-5">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button key={p} onClick={() => setPage(p)} className={`num w-9 h-9 rounded-xl text-[12px] font-black border-2 transition-all ${page === p ? 'bg-gradient-to-l from-amber-500 to-orange-600 text-white border-orange-700 shadow' : 'bg-white text-stone-600 border-amber-200 hover:border-amber-400'}`}>{p}</button>
              ))}
            </div>
          )}
        </>
      ) : (
        <div className="mt-6 rounded-3xl border-2 border-dashed border-amber-300 bg-amber-50/50 py-14 flex flex-col items-center text-center">
          <Inbox className="w-14 h-14 text-amber-400 mb-3" strokeWidth={1.5} />
          <p className="font-lalezar text-lg text-stone-700">لا توجد نتائج مطابقة</p>
          <p className="text-[11.5px] font-bold text-stone-500 mt-1">جرّب تعديل كلمة البحث أو الفلاتر — أو أضف حجزًا جديدًا</p>
          <button onClick={() => { setQuery(''); setPayFilter('all'); setDateFilter('all'); }} className="mt-4 rounded-2xl border-2 border-amber-300 bg-white text-amber-800 font-black text-[12px] px-5 py-2.5 hover:bg-amber-50">مسح الفلاتر</button>
        </div>
      )}
    </section>
  );
}
