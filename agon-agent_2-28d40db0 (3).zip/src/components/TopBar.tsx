import { useState } from 'react';
import { Bell, BellRing, ChevronDown, Download, Menu, MessageCircle, Sparkles, X } from 'lucide-react';
import type { BookingAlert } from '../lib/types';

interface Props {
  alerts: BookingAlert[];
  overdueCount: number;
  onNewBooking: () => void;
}

const NAV = [
  { label: 'الرئيسية', href: '#home' },
  { label: 'حجز جديد', href: '#new-booking' },
  { label: 'الحجوزات', href: '#bookings' },
  { label: 'الإحصائيات', href: '#stats' },
  { label: 'التحميل', href: '#download' },
];

function VinylLogo({ size = 44 }: { size?: number }) {
  return (
    <div
      className="vinyl-spin relative rounded-full shrink-0 shadow-lg shadow-orange-500/30"
      style={{
        width: size,
        height: size,
        background:
          'repeating-radial-gradient(circle at 50% 50%, #1c1917 0px, #1c1917 2px, #3f3a34 2px, #3f3a34 3.5px)',
      }}
    >
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-[46%] h-[46%] rounded-full bg-gradient-to-br from-amber-400 via-orange-500 to-rose-600 flex items-center justify-center border-2 border-amber-950/60">
          <div className="w-1/2 h-1/2 rounded-full bg-amber-100 border border-orange-800/40" />
        </div>
      </div>
    </div>
  );
}

export default function TopBar({ alerts, overdueCount, onNewBooking }: Props) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [bellOpen, setBellOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-amber-200/70 bg-[#FFFBEF]/85 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-3 sm:px-5 h-16 flex items-center justify-between gap-2">
        {/* Logo */}
        <a href="#home" className="flex items-center gap-2.5 shrink-0 group">
          <VinylLogo size={42} />
          <div className="leading-tight">
            <span className="font-lalezar text-[21px] sm:text-[23px] text-stone-900 group-hover:text-orange-700 transition-colors">ديجي <span className="text-goldgrad">مسقط</span></span>
            <p className="text-[9.5px] sm:text-[10px] font-bold text-amber-700/90 -mt-0.5">دفتر تسجيل حجوزات الحفلات الذهبي</p>
          </div>
        </a>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-1">
          {NAV.map((n) => (
            <a key={n.href} href={n.href} className="px-3.5 py-2 rounded-xl text-[13px] font-extrabold text-stone-700 hover:text-orange-700 hover:bg-amber-100/70 transition-colors">
              {n.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Bell */}
          <div className="relative">
            <button
              onClick={() => setBellOpen((v) => !v)}
              className="relative p-2.5 rounded-2xl border-2 border-amber-200 bg-white hover:bg-amber-50 hover:border-amber-300 transition-all text-amber-700 shadow-sm"
              aria-label="التنبيهات"
            >
              {overdueCount > 0 ? <BellRing className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
              {alerts.length > 0 && (
                <span className="absolute -top-1.5 -left-1.5 min-w-5 h-5 px-1 rounded-full bg-rose-600 text-white text-[10px] font-black flex items-center justify-center border-2 border-[#FFFBEF] num">
                  {alerts.length}
                </span>
              )}
            </button>

            {bellOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setBellOpen(false)} />
                <div className="absolute left-0 sm:left-auto sm:right-0 mt-3 w-[min(92vw,400px)] z-50 rounded-2xl border-2 border-amber-200 bg-white shadow-2xl shadow-orange-900/15 overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-2.5 bg-gradient-to-l from-amber-50 to-rose-50 border-b border-amber-200">
                    <p className="font-lalezar text-sm text-stone-800 flex items-center gap-1.5"><BellRing className="w-4 h-4 text-rose-600" /> مركز التنبيهات ({alerts.length})</p>
                    <button onClick={() => setBellOpen(false)} className="p-1 rounded-lg hover:bg-stone-100"><X className="w-4 h-4 text-stone-500" /></button>
                  </div>
                  <div className="max-h-96 overflow-y-auto divide-y divide-amber-100">
                    {alerts.length === 0 && (
                      <p className="text-[12.5px] font-bold text-stone-500 text-center py-6">لا توجد تنبيهات حاليًا — كل شيء تحت السيطرة 🎧</p>
                    )}
                    {alerts.map((a) => (
                      <div key={a.id} className="px-4 py-3 hover:bg-amber-50/60 transition-colors">
                        <p className="text-[12px] font-extrabold text-stone-800 leading-snug">{a.title}</p>
                        <p className="text-[11px] font-semibold text-stone-500 mt-1 leading-relaxed">{a.body}</p>
                        {a.waLink && (
                          <a
                            href={a.waLink}
                            target="_blank"
                            rel="noreferrer"
                            className="mt-2 inline-flex items-center gap-1.5 text-[11px] font-black text-white bg-[#25D366] hover:bg-[#1fb855] transition-colors rounded-full px-3 py-1.5 shadow-sm"
                          >
                            <MessageCircle className="w-3.5 h-3.5" fill="#fff" /> تذكير عبر واتساب +968
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* تنزيل التطبيق */}
          <a
            href="#download"
            title="تنزيل التطبيق كاملًا إلى جهازك"
            className="hidden sm:inline-flex items-center gap-1.5 rounded-2xl px-3 sm:px-4 py-2.5 text-[12.5px] font-black text-stone-950 bg-gradient-to-l from-amber-400 to-yellow-300 hover:from-amber-300 hover:to-yellow-200 shadow-lg shadow-amber-500/30 border border-amber-600/40 transition-all hover:-translate-y-0.5"
          >
            <Download className="w-4 h-4" /> <span className="hidden sm:inline">تنزيل التطبيق</span>
          </a>
          {/* CTA */}
          <button
            onClick={onNewBooking}
            className="hidden sm:inline-flex items-center gap-1.5 rounded-2xl px-4 py-2.5 text-[12.5px] font-black text-white bg-gradient-to-l from-amber-500 via-orange-600 to-rose-600 hover:from-amber-400 hover:via-orange-500 hover:to-rose-500 shadow-lg shadow-orange-600/25 border border-orange-700/30 transition-all hover:-translate-y-0.5"
          >
            <Sparkles className="w-4 h-4" /> حجز جديد
          </button>

          {/* Mobile toggle */}
          <button onClick={() => setMobileOpen((v) => !v)} className="lg:hidden p-2.5 rounded-2xl border-2 border-amber-200 bg-white text-stone-700" aria-label="القائمة">
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Animated equalizer ribbon divider */}
      <div className="h-[3px] w-full bg-gradient-to-l from-amber-400 via-rose-500 to-fuchsia-600 opacity-90" />

      {/* Mobile nav */}
      {mobileOpen && (
        <div className="lg:hidden border-b border-amber-200 bg-[#FFFBEF]/97 backdrop-blur-xl">
          <div className="max-w-7xl mx-auto px-4 py-3 grid grid-cols-2 gap-2">
            <a href="#download" onClick={() => setMobileOpen(false)} className="flex items-center justify-between px-4 py-3 rounded-2xl border-2 border-amber-300 bg-gradient-to-l from-amber-400 to-yellow-300 font-black text-stone-900 text-[13px]">
              تنزيل التطبيق <Download className="w-4 h-4" />
            </a>
            {NAV.map((n) => (
              <a key={n.href} href={n.href} onClick={() => setMobileOpen(false)} className="flex items-center justify-between px-4 py-3 rounded-2xl border-2 border-amber-100 bg-white font-extrabold text-stone-700 text-[13px] hover:border-amber-300 hover:text-orange-700">
                {n.label} <ChevronDown className="w-4 h-4 -rotate-90" />
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
