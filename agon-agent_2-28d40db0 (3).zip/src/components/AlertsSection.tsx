import { motion, AnimatePresence } from 'framer-motion';
import { BellRing, MessageCircle, CalendarClock, CalendarCheck2, CalendarRange, ChevronLeft, ShieldCheck } from 'lucide-react';
import type { BookingAlert } from '../lib/types';
import { OMR } from '../lib/utils';

const KIND = {
  overdue: { wrap: 'border-rose-300 bg-gradient-to-l from-rose-50 to-red-50', icon: 'bg-gradient-to-br from-rose-500 to-red-600', accent: 'text-rose-700', Ico: BellRing, waBtn: true },
  today: { wrap: 'border-amber-300 bg-gradient-to-l from-amber-50 to-yellow-50', icon: 'bg-gradient-to-br from-amber-400 to-orange-500', accent: 'text-amber-800', Ico: CalendarCheck2, waBtn: true },
  tomorrow: { wrap: 'border-violet-300 bg-gradient-to-l from-violet-50 to-purple-50', icon: 'bg-gradient-to-br from-violet-400 to-purple-600', accent: 'text-violet-800', Ico: CalendarClock, waBtn: true },
  week: { wrap: 'border-sky-300 bg-gradient-to-l from-sky-50 to-cyan-50', icon: 'bg-gradient-to-br from-sky-400 to-blue-600', accent: 'text-sky-800', Ico: CalendarRange, waBtn: true },
} as const;

interface Props {
  alerts: BookingAlert[];
  onEditBooking: (id: string) => void;
}

export default function AlertsSection({ alerts, onEditBooking }: Props) {
  return (
    <div className="rounded-[26px] border-2 border-rose-200 bg-white shadow-[0_18px_50px_-25px_rgba(225,29,72,0.4)] overflow-hidden">
      <div className="flex items-center gap-3 px-5 pt-4 pb-3 bg-gradient-to-l from-rose-50 via-orange-50 to-amber-50 border-b-2 border-rose-100">
        <span className="relative w-11 h-11 rounded-2xl bg-gradient-to-br from-rose-500 to-red-600 flex items-center justify-center text-white shadow-lg shadow-rose-500/40">
          <BellRing className="w-6 h-6" />
          {alerts.length > 0 && <span className="absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full bg-stone-900 border-2 border-white text-[9px] font-black flex items-center justify-center text-amber-300 num">{alerts.length}</span>}
        </span>
        <div>
          <h2 className="font-lalezar text-lg sm:text-xl text-stone-900 leading-none">مركز التنبيهات والإشعارات</h2>
          <p className="text-[10px] sm:text-[10.5px] font-bold text-rose-700/80 mt-1">تذكير واتساب +968 تلقائي بعد 3 أيام دون دفع + تحذيرات قرب موعد الحفل — وتصلك كإشعارات على هاتفك</p>
        </div>
      </div>

      <div className="p-3 sm:p-4 max-h-[430px] overflow-y-auto space-y-2">
        {alerts.length === 0 ? (
          <div className="flex flex-col items-center text-center py-8">
            <ShieldCheck className="w-12 h-12 text-emerald-500 mb-2" strokeWidth={1.6} />
            <p className="font-lalezar text-base text-stone-700">كل الدفوعات والحفلات تحت السيطرة</p>
            <p className="text-[10.5px] font-bold text-stone-500 mt-1">ما في حجز متأخر +3 أيام ولا حفل قريب — نرجع هنا أول ما يصير فيه شيء</p>
          </div>
        ) : (
          <AnimatePresence initial={false}>
            {alerts.map((a) => {
              const k = KIND[a.kind];
              return (
                <motion.div
                  key={a.id}
                  layout
                  initial={{ opacity: 0, x: 60 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -60 }}
                  className={`relative rounded-2xl border-2 ${k.wrap} p-3 flex items-start gap-2.5`}
                >
                  <span className={`w-10 h-10 shrink-0 rounded-xl ${k.icon} text-white flex items-center justify-center shadow`}>
                    <k.Ico className="w-5 h-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] sm:text-[11.5px] font-black text-stone-800 leading-snug">{a.title}</p>
                    <p className="text-[9.5px] sm:text-[10px] font-bold text-stone-500 leading-relaxed mt-0.5">{a.body}</p>
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      {a.waLink && (
                        <a
                          href={a.waLink}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1.5 rounded-full bg-[#25D366] hover:bg-[#1fb855] transition-colors text-white text-[10px] font-black pl-3 pr-2 py-1.5 shadow-sm shadow-green-600/30"
                        >
                          <MessageCircle className="w-3.5 h-3.5" fill="#fff" />
                          واتساب +968 للتذكير
                        </a>
                      )}
                      <button
                        onClick={() => onEditBooking(a.bookingId)}
                        className="inline-flex items-center gap-1 rounded-full bg-white/80 border border-stone-200 hover:border-amber-400 hover:text-orange-800 transition-colors text-stone-600 text-[10px] font-black px-3 py-1.5"
                      >
                        فتح الحجز <ChevronLeft className="w-3 h-3" />
                      </button>
                      {a.remaining > 0 && <span className="num text-[9px] font-black text-stone-400">المتبقي: {OMR(a.remaining)}</span>}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
