import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, Info, TriangleAlert, XCircle, X } from 'lucide-react';
import type { ToastItem, ToastKind } from '../lib/types';

const STYLE: Record<ToastKind, { ring: string; icon: string; chip: string }> = {
  success: { ring: 'border-emerald-300 bg-emerald-50', icon: 'text-emerald-600', chip: 'bg-emerald-500' },
  error: { ring: 'border-rose-300 bg-rose-50', icon: 'text-rose-600', chip: 'bg-rose-500' },
  info: { ring: 'border-sky-300 bg-sky-50', icon: 'text-sky-600', chip: 'bg-sky-500' },
  warning: { ring: 'border-amber-300 bg-amber-50', icon: 'text-amber-600', chip: 'bg-amber-500' },
};

function KindIcon({ kind }: { kind: ToastKind }) {
  const cls = 'w-5 h-5 shrink-0 ';
  switch (kind) {
    case 'success': return <CheckCircle2 className={cls + 'text-emerald-600'} />;
    case 'error': return <XCircle className={cls + 'text-rose-600'} />;
    case 'info': return <Info className={cls + 'text-sky-600'} />;
    case 'warning': return <TriangleAlert className={cls + 'text-amber-600'} />;
  }
}

export default function ToastStack({ toasts, dismiss }: { toasts: ToastItem[]; dismiss: (id: number) => void }) {
  return (
    <div className="fixed bottom-5 left-4 sm:left-6 z-[70] flex flex-col gap-2.5 w-[min(92vw,380px)]" dir="rtl">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, x: -90, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -60, scale: 0.92 }}
            transition={{ type: 'spring', stiffness: 380, damping: 30 }}
            className={`relative overflow-hidden rounded-2xl border-2 shadow-xl shadow-stone-900/10 backdrop-blur-sm px-4 py-3 flex items-start gap-3 ${STYLE[t.kind].ring}`}
          >
            <span className={`absolute top-0 bottom-0 right-0 w-1.5 ${STYLE[t.kind].chip}`} />
            <KindIcon kind={t.kind} />
            <div className="min-w-0 flex-1 pr-1">
              <p className="text-[13.5px] font-extrabold text-stone-800 leading-snug">{t.title}</p>
              {t.msg && <p className="text-[12px] font-semibold text-stone-600 mt-0.5 leading-relaxed">{t.msg}</p>}
            </div>
            <button onClick={() => dismiss(t.id)} className="p-1 rounded-lg hover:bg-stone-900/5 text-stone-400 hover:text-stone-700 transition-colors" aria-label="إغلاق">
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
