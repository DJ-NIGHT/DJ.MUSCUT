import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Download, Smartphone, FileCode2, FileArchive, CheckCircle2, Loader2, X,
  Share, PlusSquare, BadgeCheck, WifiOff, BellRing, HardDriveDownload, ListChecks, ShieldCheck,
} from 'lucide-react';
import type { BeforeInstallPromptEvent } from '../lib/download';
import { DOWNLOAD_FILES, downloadFileWithProgress, downloadJSON, isIOS, isStandaloneDisplay } from '../lib/download';
import type { Booking } from '../lib/types';
import type { ToastKind } from '../lib/types';

interface Props {
  bookings: Booking[];
  pushToast: (kind: ToastKind, title: string, msg?: string) => void;
}

export default function DownloadSection({ bookings, pushToast }: Props) {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(() => (typeof window !== 'undefined' ? isStandaloneDisplay() : false));
  const [progress, setProgress] = useState<{ kind: 'standalone' | 'source'; percent: number } | null>(null);
  const [donePulse, setDonePulse] = useState<'standalone' | 'source' | null>(null);
  const [iosModal, setIosModal] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  /* التقط حدث التثبيت قبل أن يطلقه المتصفح */
  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferred(null);
      pushToast('success', 'تم تثبيت ديجي مسقط على جهازك!', 'ستجده الآن على الشاشة الرئيسية يعمل كتطبيق مستقل');
    };
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, [pushToast]);

  const startDownload = async (kind: 'standalone' | 'source') => {
    if (progress) return;
    const meta = DOWNLOAD_FILES[kind];
    setProgress({ kind, percent: 0 });
    try {
      await downloadFileWithProgress(meta.path, meta.name, (percent) =>
        setProgress({ kind, percent })
      );
      setDonePulse(kind);
      window.setTimeout(() => setDonePulse(null), 2600);
      pushToast(
        'success',
        kind === 'standalone' ? 'اكتمل تنزيل التطبيق!' : 'اكتمل تنزيل نسخة المصدر!',
        kind === 'standalone'
          ? 'ملف «ديجي-مسقط.html» في مجلد التنزيلات — افتحه بأي متصفح ويعمل بدون نت'
          : 'ملف ZIP في مجلد التنزيلات — فك الضغط ثم npm install && npm run dev'
      );
    } catch (err) {
      pushToast('error', 'تعذر التنزيل', err instanceof Error ? err.message : 'تحقق من اتصالك وحاول مرة أخرى');
    } finally {
      window.setTimeout(() => setProgress(null), 700);
    }
  };

  const handleInstall = async () => {
    if (installed) {
      pushToast('info', 'التطبيق مثبّت بالفعل', 'ديجي مسقط يعمل الآن كتطبيق مستقل على هذا الجهاز');
      return;
    }
    if (deferred) {
      await deferred.prompt();
      const { outcome } = await deferred.userChoice;
      setDeferred(null);
      pushToast(
        outcome === 'accepted' ? 'success' : 'info',
        outcome === 'accepted' ? 'جارٍ تثبيت التطبيق…' : 'يمكنك التثبيت لاحقًا من نفس الزر'
      );
      return;
    }
    // لا يدعم المتصفح الحدث (iOS Safari مثلًا) — نعرض الخطوات اليدوية
    setIosModal(true);
  };

  const backupJSON = () => {
    downloadJSON(`ديجي-مسقط-حجوزاتي-${new Date().toISOString().slice(0, 10)}.json`, bookings);
    pushToast('success', 'تم تنزيل نسخة بياناتك', `${bookings.length} حجزًا محفوظًا في ملف JSON على جهازك`);
  };

  const installLabel = installed ? 'التطبيق مثبّت على جهازك' : 'تثبيت التطبيق على الشاشة الرئيسية';

  return (
    <section id="download" ref={sectionRef} className="max-w-7xl mx-auto px-4 sm:px-6 pb-12 scroll-mt-24">
      {/* ===== golden download banner ===== */}
      <div className="relative overflow-hidden rounded-[30px] border-2 border-amber-300 shadow-[0_30px_80px_-30px_rgba(217,119,6,0.5)]">
        {/* warm layered backdrop */}
        <div className="absolute inset-0 bg-gradient-to-bl from-amber-400 via-orange-500 to-rose-600" />
        <div className="absolute inset-0 opacity-25" style={{ backgroundImage: 'radial-gradient(circle at 18% 22%, #fff7d6 0, transparent 34%), radial-gradient(circle at 82% 78%, #ffd9e8 0, transparent 36%), radial-gradient(rgba(255,255,255,.5) 1.2px, transparent 1.2px)', backgroundSize: '100% 100%, 100% 100%, 26px 26px' }} />
        <div className="absolute -top-16 -left-16 w-72 h-72 rounded-full bg-yellow-300/40 blur-3xl" />
        <div className="absolute -bottom-20 -right-14 w-80 h-80 rounded-full bg-rose-800/35 blur-3xl" />

        <div className="relative grid lg:grid-cols-12 gap-6 items-center p-5 sm:p-8 lg:p-10">
          {/* ===== right copy ===== */}
          <div className="lg:col-span-7 text-white">
            <div className="inline-flex items-center gap-2 rounded-full bg-black/25 border border-white/25 backdrop-blur px-4 py-1.5 text-[11px] font-black tracking-wide text-amber-100">
              <HardDriveDownload className="w-4 h-4" /> منطقة التحميل — كل الأزرار تشغّل تنزيلًا حقيقيًا
            </div>
            <h2 className="font-lalezar text-[32px] sm:text-5xl leading-[1.18] mt-3 drop-shadow-sm">
              حمّل <span className="text-yellow-200">ديجي مسقط</span><br />كاملًا إلى جهازك بضغطة زر
            </h2>
            <p className="mt-3 text-[12.5px] sm:text-[14px] font-bold text-amber-50/95 leading-7 max-w-xl">
              التطبيق كاملًا — كل الحجوزات والزفات والمبالغ وزر «حفظ الحجز» — يُنزَّل إلى هاتفك أو كمبيوتر كملف واحد يعمل بدون نت، أو يُثبَّت
              كتطبيق مستقل على شاشتك الرئيسية، أو كنسخة ZIP كاملة بملفات المصدر للتعديل والتطوير.
            </p>

            {/* ===== THE BUTTONS ===== */}
            <div className="mt-6 flex flex-wrap items-stretch gap-2.5 sm:gap-3">
              {/* 1) التطبيق لملف واحد */}
              <DownloadButton
                tone="dark"
                icon={<FileCode2 className="w-6 h-6" />}
                title="تنزيل التطبيق كاملًا (HTML)"
                sub={DOWNLOAD_FILES.standalone.size + ' • يعمل بدون إنترنت'}
                busy={progress?.kind === 'standalone'}
                percent={progress?.kind === 'standalone' ? progress.percent : 0}
                done={donePulse === 'standalone'}
                onClick={() => startDownload('standalone')}
              />
              {/* 2) نسخة المصدر ZIP */}
              <DownloadButton
                tone="light"
                icon={<FileArchive className="w-6 h-6" />}
                title="تنزيل المصدر (ZIP)"
                sub="المشروع كامل • npm install && npm run dev"
                busy={progress?.kind === 'source'}
                percent={progress?.kind === 'source' ? progress.percent : 0}
                done={donePulse === 'source'}
                onClick={() => startDownload('source')}
              />
              {/* 3) تثبيت PWA */}
              <button
                onClick={handleInstall}
                className="group relative inline-flex items-center gap-3 rounded-2xl border-2 border-white/80 bg-white/95 text-stone-900 pl-5 pr-4 py-3 shadow-xl hover:-translate-y-0.5 hover:shadow-2xl transition-all text-right"
              >
                <span className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-green-600 text-white flex items-center justify-center shadow group-hover:scale-105 transition-transform">
                  {installed ? <BadgeCheck className="w-6 h-6" /> : <Smartphone className="w-6 h-6" />}
                </span>
                <span>
                  <span className="block font-lalezar text-[14px] sm:text-[15px] leading-tight">{installLabel}</span>
                  <span className="block text-[9.5px] font-bold text-stone-500 mt-0.5">{installed ? 'يعمل كتطبيق مستقل — بدون متجر' : 'بدون متجر • بضغطة واحدة • أيقونة على شاشتك'}</span>
                </span>
              </button>
            </div>

            {/* ===== نسخة احتياطية لبياناتك ===== */}
            <button onClick={backupJSON} className="mt-3 inline-flex items-center gap-2 rounded-2xl bg-black/28 hover:bg-black/38 border border-white/25 backdrop-blur px-4 py-2 text-[10.5px] sm:text-[11px] font-black text-amber-100 transition-all">
              <ListChecks className="w-4 h-4" /> تنزيل نسخة احتياطية من حجوزاتي الحالية ({bookings.length} حجزًا — JSON)
            </button>

            <div className="mt-4 flex flex-wrap gap-x-5 gap-y-1.5 text-[9.5px] sm:text-[10.5px] font-bold text-amber-50/90">
              <span className="flex items-center gap-1.5"><WifiOff className="w-4 h-4" /> النسخة المنفردة تعمل دون نت 100%</span>
              <span className="flex items-center gap-1.5"><BellRing className="w-4 h-4" /> إشعارات + واتساب +968 مدمجة</span>
              <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4" /> بدون حساب وبدون اشتراك — ملكك بالكامل</span>
            </div>
          </div>

          {/* ===== left: icon + file card ===== */}
          <div className="lg:col-span-5 flex justify-center">
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4.5, repeat: Infinity, ease: 'easeInOut' }}
              className="relative w-full max-w-[330px]"
            >
              <div className="rounded-[30px] border border-white/40 bg-white/12 backdrop-blur-xl p-5 sm:p-6 shadow-2xl text-center">
                <img src="/icons/icon-512.png" alt="أيقونة تطبيق ديجي مسقط" className="w-28 h-28 sm:w-36 sm:h-36 mx-auto rounded-[26%] shadow-2xl shadow-black/40 border border-white/30" />
                <p className="font-lalezar text-white text-xl sm:text-2xl mt-4">ديجي مسقط</p>
                <p className="text-[10px] sm:text-[10.5px] font-bold text-amber-100/90 mt-0.5">الدفتر الذهبي لحجوزات الديجي المحلي — نسخة 3.2</p>

                <div className="mt-4 rounded-2xl bg-black/30 border border-white/20 divide-y divide-white/10 text-right overflow-hidden">
                  {[
                    ['نوع الملف', 'HTML منفرد + ZIP للمصدر'],
                    ['الحجم', '4 MB / 2.8 MB'],
                    ['المنصات', 'Android • iPhone • Windows • Mac'],
                    ['المتطلبات', 'أي متصفح حديث — بلا إنترنت'],
                  ].map(([k, v], i) => (
                    <div key={i} className="flex items-center justify-between gap-3 px-4 py-2">
                      <span className="text-[9.5px] sm:text-[10px] font-black text-amber-200/80">{k}</span>
                      <span className="text-[9.5px] sm:text-[10px] font-bold text-white/95 text-left" dir="auto">{v}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-4 flex items-center justify-center gap-2 text-[10px] font-black text-yellow-200">
                  <Download className="w-4 h-4 animate-bounce" /> اضغط أي زر واحفظه في جهازك الآن
                </div>
              </div>

              {/* progress overlay while downloading */}
              <AnimatePresence>
                {progress && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 z-10 rounded-[30px] bg-stone-950/78 backdrop-blur-sm flex flex-col items-center justify-center gap-3 text-white"
                  >
                    <Loader2 className="w-10 h-10 animate-spin text-amber-400" />
                    <p className="font-lalezar text-lg">جارٍ التنزيل… {progress.percent}%</p>
                    <div className="w-48 h-3 rounded-full bg-white/15 overflow-hidden border border-white/20">
                      <div className="h-full bg-gradient-to-l from-amber-400 to-orange-500 rounded-full transition-all duration-150" style={{ width: `${progress.percent}%` }} />
                    </div>
                    <p className="text-[10px] font-bold text-amber-100/80">{progress.kind === 'standalone' ? DOWNLOAD_FILES.standalone.name : DOWNLOAD_FILES.source.name}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        </div>
      </div>

      {/* ===== iOS install helper modal ===== */}
      <AnimatePresence>
        {iosModal && (
          <motion.div key="ios-dl" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[65] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-stone-950/60 backdrop-blur-sm" onClick={() => setIosModal(false)} />
            <motion.div
              initial={{ scale: 0.85, y: 40 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 320, damping: 26 }}
              className="relative w-full max-w-md rounded-[26px] border-2 border-amber-300 bg-white shadow-2xl overflow-hidden"
            >
              <div className="bg-gradient-to-l from-amber-400 to-orange-500 px-6 py-4 flex items-center gap-3 text-white">
                <Smartphone className="w-7 h-7" />
                <div>
                  <h3 className="font-lalezar text-lg leading-none">أضف ديجي مسقط لشاشتك الرئيسية</h3>
                  <p className="text-[10px] font-bold text-amber-50 mt-1">{isIOS() ? 'Safari على iPhone / iPad' : 'متصفحك الحالي'} لا يعرض زر التثبيت التلقائي — خطوات يدوية سريعة:</p>
                </div>
                <button onClick={() => setIosModal(false)} className="mr-auto p-2 rounded-xl hover:bg-white/20"><X className="w-5 h-5" /></button>
              </div>
              <ol className="p-6 space-y-4 text-[12px] font-bold text-stone-700">
                <li className="flex items-start gap-3"><span className="w-7 h-7 shrink-0 rounded-full bg-amber-100 border border-amber-300 text-amber-800 flex items-center justify-center font-black">1</span><span className="flex items-center gap-1.5 flex-wrap">اضغط زر <b>المشاركة</b> <Share className="w-4 h-4 inline text-sky-600" /> أسفل Safari</span></li>
                <li className="flex items-start gap-3"><span className="w-7 h-7 shrink-0 rounded-full bg-amber-100 border border-amber-300 text-amber-800 flex items-center justify-center font-black">2</span><span className="flex items-center gap-1.5 flex-wrap">اختر <b>«إضافة إلى الشاشة الرئيسية»</b> <PlusSquare className="w-4 h-4 inline text-emerald-600" /> من القائمة</span></li>
                <li className="flex items-start gap-3"><span className="w-7 h-7 shrink-0 rounded-full bg-amber-100 border border-amber-300 text-amber-800 flex items-center justify-center font-black">3</span><span>اضغط <b>إضافة</b> — ستظهر أيقونة ديجي مسقط ذهبيّة على شاشتك وتعمل كتطبيق مستقل</span></li>
              </ol>
              <div className="px-6 pb-6">
                <button onClick={() => setIosModal(false)} className="w-full inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 font-lalezar text-[15px] text-white bg-gradient-to-l from-amber-500 to-orange-600 shadow-lg hover:-translate-y-0.5 transition-all">
                  <CheckCircle2 className="w-5 h-5" /> فهمت، تم
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

/* ================= زر التنزيل الذكي ================= */
interface BtnProps {
  tone: 'dark' | 'light';
  icon: React.ReactNode;
  title: string;
  sub: string;
  busy: boolean;
  percent: number;
  done: boolean;
  onClick: () => void;
}

function DownloadButton({ tone, icon, title, sub, busy, percent, done, onClick }: BtnProps) {
  const base = 'group relative inline-flex items-center gap-3 rounded-2xl border-2 pl-5 pr-4 py-3 shadow-xl hover:-translate-y-0.5 hover:shadow-2xl transition-all text-right overflow-hidden min-w-[220px]';
  const skin =
    tone === 'dark'
      ? 'border-stone-900/60 bg-stone-950 text-amber-300 hover:bg-stone-900'
      : 'border-white/80 bg-white/95 text-stone-900';
  return (
    <button onClick={onClick} disabled={busy} className={`${base} ${skin} ${busy ? 'cursor-wait' : ''}`}>
      {/* progress fill */}
      {busy && <span className="absolute inset-y-0 right-0 bg-amber-400/25 transition-all duration-150" style={{ width: `${percent}%` }} />}
      <span className={`relative w-12 h-12 shrink-0 rounded-xl flex items-center justify-center shadow transition-transform group-hover:scale-105 ${
        done ? 'bg-emerald-500 text-white' : tone === 'dark' ? 'bg-gradient-to-br from-amber-400 to-orange-600 text-stone-950' : 'bg-gradient-to-br from-amber-400 to-orange-500 text-white'
      }`}>
        {busy ? <Loader2 className="w-6 h-6 animate-spin" /> : done ? <CheckCircle2 className="w-6 h-6" /> : icon}
      </span>
      <span className="relative">
        <span className="block font-lalezar text-[13px] sm:text-[14.5px] leading-tight text-current">{done ? 'اكتمل التنزيل!' : title}</span>
        <span className={`block text-[9px] sm:text-[9.5px] font-bold mt-0.5 ${tone === 'dark' ? 'text-amber-100/75' : 'text-stone-500'}`}>{busy ? `جارٍ التحميل… ${percent}%` : sub}</span>
      </span>
      {!busy && !done && <Download className={`relative w-5 h-5 mr-auto opacity-80 group-hover:translate-y-0.5 transition-transform ${tone === 'dark' ? 'text-amber-400' : 'text-orange-600'}`} />}
    </button>
  );
}
