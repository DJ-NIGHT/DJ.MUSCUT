import { motion } from 'framer-motion';
import { CalendarPlus, LayoutList, Music4, CalendarHeart, Sparkles, BadgeCheck, Banknote, BellRing, Download } from 'lucide-react';
import HeroEq from './HeroEq';
import type { Booking } from '../lib/types';
import { OMR, remaining } from '../lib/utils';

interface Props {
  bookings: Booking[];
  onNewBooking: () => void;
  onViewBookings: () => void;
}

const MARQUEE = [
  '🎧 تجهيز نظام الصوت الكامل والإضاءة لكل حفل',
  '💍 زفات عروس ومعرس على طلبكم بأحلى الأصوات',
  '⏰ تذكير واتساب تلقائي لأي مبلغ متبقٍ بعد 3 أيام',
  '🔔 إشعارات تحذير فورية عند اقتراب موعد الحفل',
  '📀 مكتبة زفات خليجية وعمانية تراثية جاهزة',
  '🛡️ إيصالات وحجوزات موثقة وقابلة للطباعة والنسخ الاحتياطي',
];

export default function Hero({ bookings, onNewBooking, onViewBookings }: Props) {
  const total = bookings.length;
  const upcoming = bookings.filter((b) => new Date(b.eventDate + 'T23:59:59') >= new Date()).length;
  const collected = bookings.reduce((s, b) => s + b.paidAmount, 0);
  const outstanding = bookings.reduce((s, b) => s + remaining(b.totalAmount, b.paidAmount), 0);

  return (
    <section id="home" className="relative overflow-hidden">
      {/* ---- photo backdrop with light warm wash ---- */}
      <div className="absolute inset-0">
        <img src="/images/hero-dj.jpg" alt="ديجي يؤدي في حفلة عمانية" className="w-full h-full object-cover object-[62%_center]" />
        <div className="absolute inset-0 bg-gradient-to-l from-[#FFFBEF]/96 via-[#FFF6E4]/88 to-[#FFF0D8]/35" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#fdf6ea] via-transparent to-[#fdf6ea]/60" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-10 sm:pt-14 pb-8 lg:pb-12">
        <div className="grid lg:grid-cols-12 gap-6 lg:gap-8 items-center">
          {/* ===== Right copy (RTL first) ===== */}
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55 }}
              className="inline-flex items-center gap-2 rounded-full border border-amber-300 bg-white/80 backdrop-blur px-4 py-1.5 shadow-sm mb-4"
            >
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
              </span>
              <span className="text-[11.5px] font-black text-amber-800">نظام إدارة الحجوزات حي ومباشر — مسقط والسيب والبوشر</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.08 }}
              className="font-lalezar text-[33px] sm:text-5xl xl:text-[56px] leading-[1.22] text-stone-900"
            >
              سجّل حجوزات <span className="text-goldgrad">الديجي المحلي</span><br />
              للحفلات <span className="text-goldgrad">باحترافية كاملة</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.16 }}
              className="mt-3 sm:mt-4 text-[13.5px] sm:text-[15px] font-bold text-stone-700 leading-7 sm:leading-8 max-w-2xl"
            >
              وثّق بيانات صاحب الحفل والهاتف وتاريخ ومكان الحفل وزفات العروس والمعرس والمبالغ —
              الإجمالي والمدفوع والمتبقي. وإن تأخّر السداد <span className="text-rose-700">أكثر من 3 أيام</span> يصلك
              الرابط وواتساب العميل على الرقم العُماني <span className="num text-emerald-700" dir="ltr">+968</span> تلقائيًا،
              وتحصل على إشعارات تحذير على الهاتف فورًا.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.24 }}
              className="mt-5 sm:mt-6 flex flex-wrap items-center gap-2.5 sm:gap-3"
            >
              <button
                onClick={onNewBooking}
                className="inline-flex items-center gap-2 rounded-2xl px-5 sm:px-6 py-3 sm:py-3.5 text-[14px] sm:text-[15px] font-black text-white bg-gradient-to-l from-amber-500 via-orange-600 to-rose-600 border border-orange-800/25 shadow-xl shadow-orange-600/30 hover:shadow-2xl hover:-translate-y-0.5 transition-all"
              >
                <CalendarPlus className="w-5 h-5" /> سجّل حجز حفل الآن
              </button>
              <button
                onClick={onViewBookings}
                className="inline-flex items-center gap-2 rounded-2xl px-5 sm:px-6 py-3 sm:py-3.5 text-[14px] sm:text-[15px] font-black text-stone-800 bg-white/90 backdrop-blur border-2 border-amber-300 hover:border-amber-400 hover:text-orange-800 shadow-md transition-all"
              >
                <LayoutList className="w-5 h-5" /> سجلّ الحجوزات ({total})
              </button>
              <a
                href="#download"
                className="inline-flex items-center gap-2 rounded-2xl px-5 sm:px-6 py-3 sm:py-3.5 text-[14px] sm:text-[15px] font-black text-stone-950 bg-gradient-to-l from-yellow-300 to-amber-400 border-2 border-amber-500/60 shadow-lg shadow-amber-500/30 hover:shadow-xl hover:-translate-y-0.5 transition-all"
              >
                <Download className="w-5 h-5" /> تنزيل التطبيق
              </a>
            </motion.div>

            {/* mini stats strip */}
            <motion.div
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.32 }}
              className="mt-5 sm:mt-7 grid grid-cols-2 sm:grid-cols-4 gap-2 max-w-2xl"
            >
              {[
                { icon: CalendarHeart, label: 'حفلات قادمة', value: String(upcoming), tone: 'text-violet-700 bg-violet-50 border-violet-200' },
                { icon: Banknote, label: 'محصّل', value: OMR(collected), tone: 'text-emerald-700 bg-emerald-50 border-emerald-200' },
                { icon: BellRing, label: 'متبقّي متوقع', value: OMR(outstanding), tone: 'text-rose-700 bg-rose-50 border-rose-200' },
                { icon: BadgeCheck, label: 'دقة وتوثيق', value: '100%', tone: 'text-amber-800 bg-amber-50 border-amber-200' },
              ].map((s, i) => (
                <div key={i} className={`rounded-2xl border-2 backdrop-blur px-3 py-2 ${s.tone} shadow-sm`}>
                  <s.icon className="w-4 h-4 mb-1 opacity-80" />
                  <p className="num text-[13px] sm:text-[13.5px] font-black leading-tight truncate" dir="ltr" style={{ textAlign: 'right' }}>{s.value}</p>
                  <p className="text-[9.5px] sm:text-[10px] font-extrabold opacity-80">{s.label}</p>
                </div>
              ))}
            </motion.div>
          </div>

          {/* ===== Left floating deck card (dark glass) ===== */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <motion.div
              initial={{ opacity: 0, scale: 0.85, rotate: -2 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ type: 'spring', stiffness: 160, damping: 20, delay: 0.25 }}
              className="floaty relative w-full max-w-[340px] sm:max-w-[380px] rounded-[28px] border border-white/15 bg-gradient-to-b from-stone-900/92 via-stone-900/88 to-[#2b0a12]/92 backdrop-blur-xl shadow-[0_30px_80px_-20px_rgba(120,20,40,0.55)] p-5 text-amber-50"
            >
              {/* glow orbs */}
              <div className="absolute -top-10 -right-10 w-44 h-44 rounded-full bg-fuchsia-600/30 blur-3xl pointer-events-none" />
              <div className="absolute -bottom-12 -left-10 w-48 h-48 rounded-full bg-amber-500/25 blur-3xl pointer-events-none" />

              <div className="relative">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 to-rose-600 flex items-center justify-center">
                      <Music4 className="w-4.5 h-4.5 text-white" />
                    </span>
                    <div className="leading-tight">
                      <p className="font-lalezar text-[14px] text-amber-100">LIVE — ديجي مسقط</p>
                      <p className="text-[9.5px] font-bold text-amber-200/70">قصر المروج الملكية • الليلة 9:30</p>
                    </div>
                  </div>
                  <span className="flex items-center gap-1.5 rounded-full bg-rose-600/90 px-2.5 py-1 text-[9.5px] font-black tracking-widest">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> ON AIR
                  </span>
                </div>

                <div className="my-4">
                  <HeroEq />
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  {[
                    { l: 'زفة العروس', v: 'جاري التشغيل' },
                    { l: 'زفة المعرس', v: 'القائمة جاهزة' },
                    { l: 'الصوت', v: '24bit / لايف' },
                  ].map((x, i) => (
                    <div key={i} className="rounded-2xl bg-white/5 border border-white/10 py-2 px-1">
                      <p className="text-[9px] font-bold text-amber-200/70">{x.l}</p>
                      <p className="text-[10px] font-black text-amber-100 mt-0.5">{x.v}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-4 flex items-center justify-between rounded-2xl border border-amber-400/25 bg-amber-400/10 px-3.5 py-2.5">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <p className="text-[10.5px] font-black text-amber-100">+1,240 حفل نُظّم منذ 2011</p>
                  </div>
                  <p className="font-lalezar text-[15px] text-amber-300 num">4.9<span className="text-[10px] text-amber-200/70">/5</span></p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* ===== marquee ticker ===== */}
        <div className="relative mt-7 sm:mt-9 rounded-2xl border border-amber-300/80 bg-white/85 backdrop-blur overflow-hidden shadow-sm">
          <div className="marquee-track flex whitespace-nowrap py-2">
            {[...MARQUEE, ...MARQUEE].map((m, i) => (
              <span key={i} className="mx-6 text-[11px] sm:text-[12px] font-extrabold text-amber-900">{m}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
