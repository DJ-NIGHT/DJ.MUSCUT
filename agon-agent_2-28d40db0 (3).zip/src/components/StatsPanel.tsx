import { useMemo } from 'react';
import { Wallet, Banknote, PiggyBank, Percent, PieChart as PieIcon, BarChart3, MapPin } from 'lucide-react';
import type { Booking, PayStatus } from '../lib/types';
import { OMR, remaining, payStatusOf } from '../lib/utils';

export default function StatsPanel({ bookings }: { bookings: Booking[] }) {
  const stats = useMemo(() => {
    const totals = bookings.reduce(
      (acc, b) => {
        acc.total += b.totalAmount;
        acc.paid += b.paidAmount;
        acc.rem += remaining(b.totalAmount, b.paidAmount);
        const st = payStatusOf(b.totalAmount, b.paidAmount);
        acc.byStatus[st] += 1;
        return acc;
      },
      { total: 0, paid: 0, rem: 0, byStatus: { paid: 0, partial: 0, unpaid: 0 } as Record<PayStatus, number> }
    );
    const rate = totals.total > 0 ? Math.min(100, (totals.paid / totals.total) * 100) : 0;

    // top venues
    const venueMap = new Map<string, { count: number; collected: number }>();
    for (const b of bookings) {
      const key = b.venue.split('–')[0].trim();
      const cur = venueMap.get(key) ?? { count: 0, collected: 0 };
      cur.count += 1;
      cur.collected += b.paidAmount;
      venueMap.set(key, cur);
    }
    const venues = [...venueMap.entries()].sort((a, b) => b[1].count - a[1].count).slice(0, 5);
    const maxVenue = Math.max(1, ...venues.map(([, v]) => v.count));

    // 6-month revenue series (by event month)
    const months: { label: string; value: number }[] = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const label = d.toLocaleDateString('ar-OM', { month: 'short' });
      const value = bookings
        .filter((b) => {
          const ev = new Date(b.eventDate + 'T00:00:00');
          return ev.getFullYear() === d.getFullYear() && ev.getMonth() === d.getMonth();
        })
        .reduce((s, b) => s + b.paidAmount, 0);
      months.push({ label, value });
    }
    const maxMonth = Math.max(1, ...months.map((m) => m.value));

    return { ...totals, rate, venues, maxVenue, months, maxMonth };
  }, [bookings]);

  const donut = useMemo(() => {
    const segs = [
      { label: 'مدفوع', value: stats.byStatus.paid, color: '#10B981' },
      { label: 'جزئي', value: stats.byStatus.partial, color: '#F59E0B' },
      { label: 'غير مدفوع', value: stats.byStatus.unpaid, color: '#F43F5E' },
    ];
    const total = segs.reduce((s, x) => s + x.value, 0) || 1;
    let offset = 25; // start at top
    const R = 15.9155; // circumference = 100
    return segs.map((s) => {
      const frac = (s.value / total) * 100;
      const el = { ...s, dash: `${frac} ${100 - frac}`, offset };
      offset -= frac;
      return el;
    });
  }, [stats]);

  const KPIS = [
    { icon: Wallet, label: 'إجمالي قيمة الحجوزات', value: OMR(stats.total), cls: 'from-amber-400 to-orange-500', chip: 'bg-amber-50 border-amber-200 text-amber-900' },
    { icon: Banknote, label: 'المحصّل فعليًا', value: OMR(stats.paid), cls: 'from-emerald-400 to-green-600', chip: 'bg-emerald-50 border-emerald-200 text-emerald-900' },
    { icon: PiggyBank, label: 'المتبقي للتحصيل', value: OMR(stats.rem), cls: 'from-rose-400 to-red-600', chip: 'bg-rose-50 border-rose-200 text-rose-900' },
    { icon: Percent, label: 'نسبة التحصيل العامة', value: `${stats.rate.toFixed(1)}%`, cls: 'from-violet-400 to-purple-600', chip: 'bg-violet-50 border-violet-200 text-violet-900' },
  ];

  return (
    <section id="stats" className="max-w-7xl mx-auto px-4 sm:px-6 pb-10 scroll-mt-24">
      <div className="flex items-center gap-3 mb-4">
        <span className="w-11 h-11 rounded-2xl bg-gradient-to-br from-teal-500 via-emerald-600 to-green-700 flex items-center justify-center shadow-lg shadow-emerald-600/30 text-white">
          <BarChart3 className="w-6 h-6" />
        </span>
        <div>
          <h2 className="font-lalezar text-[22px] sm:text-2xl text-stone-900 leading-none">لوحة الإحصائيات المالية</h2>
          <p className="text-[10.5px] sm:text-[11px] font-bold text-stone-500 mt-1">نظرة شاملة على التحصيل والحجوزات أولًا بأول</p>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        {KPIS.map((k, i) => (
          <div key={i} className={`rounded-3xl border-2 ${k.chip} p-3 sm:p-4 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all`}>
            <span className={`w-9 h-9 rounded-xl bg-gradient-to-br ${k.cls} text-white flex items-center justify-center shadow mb-2`}>
              <k.icon className="w-5 h-5" />
            </span>
            <p className="num text-[13px] sm:text-[16px] font-black leading-tight" dir="ltr" style={{ textAlign: 'right' }}>{k.value}</p>
            <p className="text-[9px] sm:text-[9.5px] font-black opacity-80 mt-0.5">{k.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
        {/* revenue by month — pure CSS bar chart */}
        <div className="lg:col-span-2 rounded-[26px] border-2 border-amber-200 bg-white p-4 sm:p-5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-lalezar text-base text-stone-800 flex items-center gap-2"><BarChart3 className="w-5 h-5 text-amber-600" /> الإيرادات المحصّلة حسب الشهر</h3>
            <span className="text-[9.5px] font-black text-stone-400">آخر 6 أشهر (حسب تاريخ الحفل)</span>
          </div>
          <div dir="ltr" className="flex items-end justify-between gap-2 h-40 sm:h-48 px-1 border-b-2 border-amber-100 pb-1">
            {stats.months.map((m, i) => (
              <div key={i} className="flex-1 flex flex-col items-center justify-end gap-1.5 min-w-0">
                <span className="num text-[8.5px] sm:text-[9.5px] font-black text-stone-500">{m.value > 0 ? m.value.toLocaleString('en-US') : ''}</span>
                <div
                  className="w-full max-w-[46px] rounded-t-xl bg-gradient-to-t from-amber-500 via-orange-500 to-rose-500 shadow-inner transition-all duration-700"
                  style={{ height: `${(m.value / stats.maxMonth) * 100}%`, minHeight: m.value > 0 ? 10 : 3 }}
                />
                <span className="text-[9.5px] sm:text-[10.5px] font-black text-stone-600">{m.label}</span>
              </div>
            ))}
          </div>

          {/* top venues */}
          <h3 className="font-lalezar text-base text-stone-800 flex items-center gap-2 mt-5 mb-2"><MapPin className="w-5 h-5 text-emerald-600" /> أكثر الأماكن حجزًا</h3>
          <div className="space-y-1.5">
            {stats.venues.map(([venue, v]) => (
              <div key={venue} className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-stone-600 w-32 sm:w-40 truncate shrink-0">{venue}</span>
                <div className="flex-1 h-4 rounded-full bg-stone-100 overflow-hidden">
                  <div className="h-full rounded-full bg-gradient-to-l from-teal-400 to-emerald-600 transition-all duration-700" style={{ width: `${(v.count / stats.maxVenue) * 100}%` }} />
                </div>
                <span className="num text-[10px] font-black text-stone-500 w-6 text-center">{v.count}</span>
              </div>
            ))}
            {stats.venues.length === 0 && <p className="text-[10.5px] font-bold text-stone-400">لا توجد بيانات بعد</p>}
          </div>
        </div>

        {/* donut — payment distribution */}
        <div className="rounded-[26px] border-2 border-amber-200 bg-white p-4 sm:p-5 shadow-sm flex flex-col">
          <h3 className="font-lalezar text-base text-stone-800 flex items-center gap-2 mb-1"><PieIcon className="w-5 h-5 text-violet-600" /> توزيع حالات الدفع</h3>
          <p className="text-[9.5px] font-bold text-stone-400 mb-2">{bookings.length} حجز إجمالًا</p>
          <div className="flex items-center justify-center py-2">
            <div className="relative">
              <svg viewBox="0 0 42 42" className="w-40 h-40 sm:w-44 sm:h-44 -rotate-0">
                <circle cx="21" cy="21" r="15.9155" fill="none" stroke="#F3EFE7" strokeWidth="6.5" />
                {donut.map((s, i) => (
                  <circle
                    key={i}
                    cx="21" cy="21" r="15.9155" fill="none"
                    stroke={s.color} strokeWidth="6.5"
                    strokeDasharray={s.dash}
                    strokeDashoffset={s.offset}
                    strokeLinecap="round"
                    className="transition-all duration-700"
                  />
                ))}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="num font-lalezar text-2xl text-stone-800">{bookings.length}</span>
                <span className="text-[9px] font-black text-stone-400">حجز</span>
              </div>
            </div>
          </div>
          <div className="mt-auto space-y-1.5 pt-2 border-t border-dashed border-amber-200">
            {donut.map((s) => (
              <div key={s.label} className="flex items-center gap-2 text-[11px] font-black text-stone-700">
                <span className="w-3.5 h-3.5 rounded-md" style={{ background: s.color }} />
                {s.label}
                <span className="num mr-auto">{s.value} حجز</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
