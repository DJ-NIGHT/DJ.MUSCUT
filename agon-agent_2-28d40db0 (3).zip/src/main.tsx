import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'

// تسجيل Service Worker ليعمل التطبيق دون إنترنت ويُثبَّت كتطبيق PWA
// (يُتخطّى تلقائيًا في الملف المنفرد file:// وفي بيئات المعاينة غير الآمنة)
if ('serviceWorker' in navigator && import.meta.env.PROD && window.location.protocol.startsWith('http')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      /* قد لا يتوفر في بعض المعاينات — التطبيق يعمل عاديًا بدونها */
    })
  })
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
