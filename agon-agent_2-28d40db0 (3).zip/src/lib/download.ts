/**
 * منطق التحميل الحقيقي — كل زر هنا يُنزّل شيئًا فعليًا على جهاز المستخدم:
 *  1) التطبيق الكامل كملف واحد (يعمل بلا إنترنت) — standalone-template.html
 *  2) نسخة المصدر الكامل للمشروع — dj-muscat-project.zip
 *  3) التثبيت على الشاشة الرئيسية عبر PWA (beforeinstallprompt)
 *  4) نسخة احتياطية JSON لبيانات الحجوزات المحفوظة
 */

export const DOWNLOAD_FILES = {
  standalone: { path: '/download/standalone-template.html', name: 'ديجي-مسقط.html', size: '≈ 4 MB' },
  source: { path: '/download/dj-muscat-project.zip', name: 'dj-muscat-project.zip', size: '≈ 2.8 MB' },
} as const;

export type DownloadKind = keyof typeof DOWNLOAD_FILES;

/** تنزيل ملف حقيقي عبر الشبكة مع progress + حفظ باسم عربي */
export async function downloadFileWithProgress(
  path: string,
  saveName: string,
  onProgress: (percent: number) => void
): Promise<void> {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`تعذر جلب الملف (${res.status})`);
  const total = Number(res.headers.get('content-length')) || 0;

  if (!res.body || !total) {
    // لا يوجد stream للقراءة — ننزّل كـ blob مباشرة
    onProgress(60);
    const blob = await res.blob();
    triggerBlobDownload(blob, saveName);
    onProgress(100);
    return;
  }

  const reader = res.body.getReader();
  const chunks: BlobPart[] = [];
  let received = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value as BlobPart);
    received += value.length;
    onProgress(Math.min(99, Math.round((received / total) * 100)));
  }
  triggerBlobDownload(new Blob(chunks), saveName);
  onProgress(100);
}

/** تنزيل بيانات JSON مباشرة (نسخة احتياطية من الحجوزات) */
export function downloadJSON(saveName: string, data: unknown) {
  triggerBlobDownload(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8' }), saveName);
}

function triggerBlobDownload(blob: Blob, saveName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = saveName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* ================= PWA install (زر التثبيت) ================= */
export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function isStandaloneDisplay(): boolean {
  return (
    window.matchMedia?.('(display-mode: standalone)').matches ||
    (window.navigator as Navigator & { standalone?: boolean }).standalone === true
  );
}

export function isIOS(): boolean {
  return /iphone|ipad|ipod/i.test(navigator.userAgent);
}
