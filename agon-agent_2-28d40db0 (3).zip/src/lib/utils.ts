import type { Booking, BookingAlert, PayStatus, ToastKind } from './types';

/* ---------- Currency & time ---------- */
export const OMR = (n: number) =>
  `${(Number.isFinite(n) ? n : 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 3 })} ر.ع`;

const AR_DAYS = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const AR_MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

export function formatArabicDate(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d.getTime())) return iso;
  return `${AR_DAYS[d.getDay()]} ${d.getDate()} ${AR_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

export function toHijri(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d.getTime())) return '';
  try {
    return new Intl.DateTimeFormat('ar-SA-u-ca-islamic', { day: 'numeric', month: 'long', year: 'numeric' }).format(d);
  } catch {
    return '';
  }
}

export function isoDate(d: Date): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export function todayISO(): string {
  return isoDate(new Date());
}

export function daysUntil(iso: string): number {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const d = new Date(iso + 'T00:00:00');
  return Math.round((d.getTime() - now.getTime()) / 86400000);
}

/* ---------- Money ---------- */
export const remaining = (total: number, paid: number) => Math.max(0, round3((total || 0) - (paid || 0)));
export const round3 = (n: number) => Math.round(n * 1000) / 1000;

export function payStatusOf(total: number, paid: number): PayStatus {
  if (!total || total <= 0) return paid > 0 ? 'paid' : 'unpaid';
  const r = remaining(total, paid);
  if (r <= 0.001) return 'paid';
  if (paid > 0) return 'partial';
  return 'unpaid';
}

export const paidPercent = (total: number, paid: number) =>
  total > 0 ? Math.min(100, Math.round((Math.min(paid, total) / total) * 100)) : paid > 0 ? 100 : 0;

/* ---------- Time helpers for the 3-day payment rule ---------- */
export function hoursSinceCreated(createdAt: string): number {
  return (Date.now() - new Date(createdAt).getTime()) / 3600000;
}

/** Booking is overdue for payment: remaining > 0 AND created at least `days` days ago. */
export function isPaymentOverdue(b: Booking, days = 3): boolean {
  return remaining(b.totalAmount, b.paidAmount) > 0.001 && hoursSinceCreated(b.createdAt) >= days * 24;
}

export function isEventPast(b: Booking): boolean {
  return daysUntil(b.eventDate) < 0;
}

/* ---------- WhatsApp (Oman +968) ---------- */
/** Normalize any Omani phone input to international format 968XXXXXXXX (8-digit national number). */
export function normalizePhone968(raw: string): string | null {
  if (!raw) return null;
  let digits = raw.replace(/[^\d]/g, '');
  if (digits.startsWith('00')) digits = digits.slice(2);
  if (digits.startsWith('968')) {
    return digits.length === 11 ? digits : digits.length > 11 ? '968' + digits.slice(-8) : null;
  }
  if (digits.startsWith('0')) digits = digits.slice(1);
  if (digits.length === 8 && /^[79]/.test(digits)) return '968' + digits;
  if (digits.length === 8) return '968' + digits;
  return null;
}

export function waRaw(phone: string): string {
  return normalizePhone968(phone) ?? phone.replace(/[^\d]/g, '');
}

export function buildReminderMessage(b: Booking): string {
  const rem = remaining(b.totalAmount, b.paidAmount);
  return (
    `السلام عليكم ورحمة الله وبركاته، الأخ ${b.ownerName} 🌸\n\n` +
    `نذكّركم بأن موعد حفل "${b.category}" المقام في ${formatArabicDate(b.eventDate)}${b.eventTime ? ' الساعة ' + b.eventTime : ''} ` +
    `في ${b.venue} يقترب، وأن هناك مبلغًا متبقيًا قدره ${OMR(rem)} من أصل ${OMR(b.totalAmount)}.\n\n` +
    `مرّ أكثر من 3 أيام على تأكيد الحجز دون إتمام الدفعة، يرجى التكرم بسداد المبلغ المتبقي لتأكيد الحجز نهائيًا.\n\n` +
    `زفة العروس: ${b.brideZaffa || '—'}\nزفة المعرس: ${b.groomZaffa || '—'}\n\n` +
    `مع تحيات فريق ديجي مسقط للحفلات 🎧✨`
  );
}

export function waLinkFor(b: Booking, customMsg?: string): string {
  const msg = customMsg ?? buildReminderMessage(b);
  return `https://wa.me/${waRaw(b.ownerPhone)}?text=${encodeURIComponent(msg)}`;
}

/* ---------- Notifications & alerts ---------- */
export function computeAlerts(bookings: Booking[]): BookingAlert[] {
  const now = new Date();
  const alerts: BookingAlert[] = [];

  for (const b of bookings) {
    const rem = remaining(b.totalAmount, b.paidAmount);
    const d = daysUntil(b.eventDate);
    const when = formatArabicDate(b.eventDate);

    // Payment overdue 3+ days with remaining balance -> WhatsApp link (the core requirement)
    if (isPaymentOverdue(b, 3)) {
      alerts.push({
        id: `overdue-${b.id}`,
        kind: 'overdue',
        bookingId: b.id,
        title: `⚠️ تأخير سداد — ${b.ownerName}`,
        body: `مرّ أكثر من 3 أيام على الحجز وبقاؤه دون دفع. المتبقي ${OMR(rem)} لحفل ${when}. اضغط للتواصل عبر واتساب +968.`,
        remaining: rem,
        waLink: waLinkFor(b),
      });
      continue;
    }

    if (d === 0) {
      alerts.push({
        id: `today-${b.id}`,
        kind: 'today',
        bookingId: b.id,
        title: `🎉 الليلة موعد الحفل! — ${b.ownerName}`,
        body: `حفل "${b.category}" اليوم ${when}${b.eventTime ? ' الساعة ' + b.eventTime : ''} في ${b.venue}. المتبقي للسداد: ${OMR(rem)}.`,
        remaining: rem,
        waLink: rem > 0 ? waLinkFor(b) : null,
      });
    } else if (d === 1) {
      alerts.push({
        id: `tomorrow-${b.id}`,
        kind: 'tomorrow',
        bookingId: b.id,
        title: `⏰ غدًا الحفل — ${b.ownerName}`,
        body: `تذكير: حفل "${b.category}" غدًا ${when} في ${b.venue}. المتبقي: ${OMR(rem)}.`,
        remaining: rem,
        waLink: rem > 0 ? waLinkFor(b) : null,
      });
    } else if (d > 1 && d <= 7 && rem > 0) {
      alerts.push({
        id: `week-${b.id}`,
        kind: 'week',
        bookingId: b.id,
        title: `📅 خلال الأسبوع — ${b.ownerName}`,
        body: `حفل "${b.category}" بعد ${d} أيام (${when}). المتبقي للسداد ${OMR(rem)} — ${b.venue}.`,
        remaining: rem,
        waLink: waLinkFor(b),
      });
    }
  }

  const rank = { overdue: 0, today: 1, tomorrow: 2, week: 3 } as const;
  return alerts.sort((a, b) => rank[a.kind] - rank[b.kind]);
}

/* ---------- CSV & backup ---------- */
export function toCSV(bookings: Booking[]): string {
  const head = ['المعرف', 'صاحب الحفل', 'هاتف صاحب الحفل', 'تاريخ الحفل', 'وقت الحفل', 'مكان الحفل', 'نوع الحفل', 'زفة العروس', 'زفة المعرس', 'المبلغ الإجمالي', 'المبلغ المدفوع', 'المبلغ المتبقي', 'حالة الدفع', 'ملاحظات', 'تاريخ إنشاء الحجز'];
  const rows = bookings.map((b) => {
    const st = payStatusOf(b.totalAmount, b.paidAmount);
    const stText = st === 'paid' ? 'مدفوع بالكامل' : st === 'partial' ? 'دفعة جزئية' : 'غير مدفوع';
    return [
      b.id, b.ownerName, b.ownerPhone, b.eventDate, b.eventTime, b.venue, b.category,
      b.brideZaffa, b.groomZaffa,
      String(b.totalAmount), String(b.paidAmount), String(remaining(b.totalAmount, b.paidAmount)), stText,
      b.notes, new Date(b.createdAt).toLocaleString('ar-OM'),
    ];
  });
  const esc = (s: string) => `"${String(s).replace(/"/g, '""')}"`;
  return [head, ...rows].map((r) => r.map(esc).join(',')).join('\r\n');
}

export function downloadFile(name: string, content: string, mime = 'text/plain;charset=utf-8') {
  const blob = new Blob(['\ufeff' + content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function timeAgoAr(iso: string): string {
  const h = hoursSinceCreated(iso);
  if (h < 1) return 'منذ دقائق';
  if (h < 24) return `منذ ${Math.floor(h)} ساعة`;
  const d = Math.floor(h / 24);
  return `منذ ${d} ${d === 1 ? 'يوم' : d === 2 ? 'يومين' : 'أيام'}`;
}

export function uid(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}
