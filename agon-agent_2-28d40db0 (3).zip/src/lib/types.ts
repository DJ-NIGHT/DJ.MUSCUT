export type Category =
  | 'زفاف'
  | 'خطوبة'
  | 'تخرج'
  | 'عقيقة'
  | 'حفل شركة'
  | 'ذكرى سنوية';

export interface Booking {
  id: string;
  ownerName: string; // صاحب الحفل
  ownerPhone: string; // هاتف صاحب الحفل
  eventDate: string; // تاريخ الحفل (YYYY-MM-DD)
  eventTime: string; // وقت الحفل (HH:MM)
  venue: string; // مكان الحفل
  brideZaffa: string; // اسم زفة العروس
  groomZaffa: string; // زفة المعرس
  totalAmount: number; // المبلغ الإجمالي
  paidAmount: number; // المبلغ المدفوع
  category: Category; // نوع الحفل
  notes: string; // ملاحظات
  createdAt: string; // ISO datetime
}

export type PayStatus = 'paid' | 'partial' | 'unpaid';

export type ToastKind = 'success' | 'error' | 'info' | 'warning';
export interface ToastItem {
  id: number;
  kind: ToastKind;
  title: string;
  msg?: string;
}

export type AlertKind = 'overdue' | 'today' | 'tomorrow' | 'week';
export interface BookingAlert {
  id: string;
  kind: AlertKind;
  bookingId: string;
  title: string;
  body: string;
  remaining: number;
  waLink: string | null;
}
