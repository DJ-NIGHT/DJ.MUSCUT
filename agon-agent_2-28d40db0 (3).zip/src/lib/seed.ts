import type { Booking, Category } from './types';
import { isoDate, uid, waLinkFor, remaining, payStatusOf } from './utils';

function daysFromNow(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return isoDate(d);
}
function daysAgo(n: number, h = 10): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  d.setHours(h, Math.floor(Math.random() * 59), 0, 0);
  return d.toISOString();
}

export function seedBookings(): Booking[] {
  const mk = (
    ownerName: string,
    ownerPhone: string,
    eventDate: string,
    eventTime: string,
    venue: string,
    brideZaffa: string,
    groomZaffa: string,
    totalAmount: number,
    paidAmount: number,
    createdDaysAgo: number,
    category: Category = 'زفاف',
    notes = ''
  ): Booking => ({
    id: uid(),
    ownerName,
    ownerPhone,
    eventDate,
    eventTime,
    venue,
    brideZaffa,
    groomZaffa,
    totalAmount,
    paidAmount,
    category,
    notes,
    createdAt: daysAgo(createdDaysAgo),
  });

  return [
    mk('سعيد بن راشد البلوشي', '96891234567', daysFromNow(3), '21:00', 'قاعة الأريانة – القرم', 'زفة "يا هلا بالمعرس" بصوت فهد العبدالمحسن', 'زفة "هلا هلا" مع المزمار البلوشي التقليدي', 850, 0, 5, 'زفاف', 'العرسان يفضلون الدخول بالمزمار مع الألعاب النارية الخفيفة'),
    mk('فهد بن سالم الزدجالي', '+968 99112233', daysFromNow(6), '20:30', 'قصر تلال مسقط – بوشر', 'زفة "عروس الخير" بصوت راشد الماجد', 'زفة "ماشاء الله" مع فرقة العيالة العمانية', 1200, 500, 6, 'زفاف', 'طلب حجز قاعة الفيروز حصراً'),
    mk('ناصر بن حمد الحراصي', '96890123456', daysFromNow(9), '21:30', 'قاعة المروج الملكية – السيب', 'زفة "بسم الله" مع فرقة التراث الشعبي', 'زفة المعرس الكبرى بصوت ماجد المهندس', 950, 950, 12, 'زفاف', ''),
    mk('ماجد بن خميس الهنائي', '96877788990', daysFromNow(1), '22:00', 'قاعة اللؤلؤة الذهبية – الغبرة', 'زفة "ليالي العمر" بصوت نايف حمدان', 'زفة "عريس الزمان" بصوت فواز اليافعي', 700, 200, 4, 'زفاف', 'الحفل في نفس يوم خطوبة أخيه الصباح'),
    mk('سالم بن علي الشكيلي', '96895566778', daysFromNow(14), '20:00', 'حديقة النادي الأهلي – روي', 'زفة "يانور العين" بصوت عبدالمجيد عبدالله', 'زفة الخليج الشعبي مع الندبة', 1500, 1000, 9, 'زفاف', 'يحتاج تشغيل المزامير والدفوف عند دخول العروس'),
    mk('حمد بن سعيد الرواحي', '96892345678', daysFromNow(0), '21:00', 'قاعة السراب الذهبية – بركاء', 'زفة "عروستنا" بصوت حسين الجسمي', 'زفة "البارحة" مع عزف مباشر على العود', 600, 600, 15, 'زفاف', 'حفل عائلي كبير، أكثر من 400 ضيف'),
    mk('خالد بن مسعود اليزيدي', '96871122334', daysFromNow(20), '19:30', 'فندق نزوى – نزوى', 'زفة "بنت الناس" بصوت أصيل أبو بكر', 'زفة المعرس النزواوية مع الرقص الشعبي', 1100, 0, 5, 'زفاف', 'سفر كامل إلى نزوى، يلزم تجهيز معدات إضافية'),
    mk('محمد بن عبدالله الكندي', '96899887766', daysFromNow(27), '20:30', 'قاعة الرمال الذهبية – مطرح', 'زفة "يا زمان" بصوت قتيبة راشد', 'زفة "تاج الرجال" مع طبول الحرب', 800, 300, 10, 'خطوبة', 'خطوبة، المبلغ يشمل بوفيه الحلويات والضيافة'),
  ];
}

export function printBooking(b: Booking) {
  const rem = remaining(b.totalAmount, b.paidAmount);
  const st = payStatusOf(b.totalAmount, b.paidAmount);
  const statusText = st === 'paid' ? 'مدفوع بالكامل' : st === 'partial' ? 'دفعة جزئية' : 'غير مدفوع';
  const w = window.open('', '_blank', 'width=820,height=1000');
  if (!w) {
    alert('تعذر فتح نافذة الطباعة — يرجى السماح بالنوافذ المنبثقة');
    return;
  }
  const now = new Date().toLocaleString('ar-OM', { dateStyle: 'full', timeStyle: 'short' });
  w.document.write(`<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8">
<title>إيصال حجز — ${b.ownerName}</title>
<style>
  body{font-family:'Cairo',Tahoma,sans-serif;background:#FFFBEB;margin:0;padding:28px;color:#1c1917}
  .sheet{max-width:680px;margin:auto;background:#fff;border:2px solid #f59e0b;border-radius:18px;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.12)}
  .head{background:linear-gradient(135deg,#f59e0b,#e11d48);color:#fff;padding:22px 26px;text-align:center}
  .head h1{margin:0;font-size:22px}.head p{margin:6px 0 0;opacity:.92;font-size:12px}
  .body{padding:22px 28px}
  table{width:100%;border-collapse:collapse;font-size:14px}
  td{padding:10px 12px;border-bottom:1px dashed #fde68a}
  td:first-child{color:#b45309;font-weight:700;width:38%}
  .totals{display:flex;gap:10px;margin-top:18px}
  .box{flex:1;text-align:center;border-radius:12px;padding:12px;border:1.5px solid}
  .box b{display:block;font-size:20px;margin-top:4px}
  .t-total{border-color:#fbbf24;background:#fffbeb;color:#92400e}
  .t-paid{border-color:#34d399;background:#ecfdf5;color:#065f46}
  .t-rem{border-color:#fb7185;background:#fff1f2;color:#9f1239}
  .status{margin-top:16px;text-align:center;font-weight:800;padding:10px;border-radius:10px;background:#fef3c7;color:#92400e}
  .foot{text-align:center;font-size:11px;color:#78716c;padding:14px;border-top:1px solid #fde68a}
  @media print{body{background:#fff;padding:0}.sheet{box-shadow:none;border:none}}
</style></head><body>
<div class="sheet">
  <div class="head"><h1>ديجي مسقط — إيصال حجز حفلة</h1><p>نظام إدارة حجوزات الديجي المحلية • رقم الحجز: ${b.id.slice(0, 8).toUpperCase()}</p></div>
  <div class="body">
    <table>
      <tr><td>صاحب الحفل</td><td>${escapeHtml(b.ownerName)}</td></tr>
      <tr><td>هاتف صاحب الحفل</td><td dir="ltr" style="text-align:right">${escapeHtml(b.ownerPhone)}</td></tr>
      <tr><td>تاريخ الحفل</td><td>${new Date(b.eventDate + 'T00:00:00').toLocaleDateString('ar-OM', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}${b.eventTime ? ' — الساعة ' + b.eventTime : ''}</td></tr>
      <tr><td>مكان الحفل</td><td>${escapeHtml(b.venue)}</td></tr>
      <tr><td>نوع الحفل</td><td>${escapeHtml(b.category)}</td></tr>
      <tr><td>زفة العروس</td><td>${escapeHtml(b.brideZaffa || '—')}</td></tr>
      <tr><td>زفة المعرس</td><td>${escapeHtml(b.groomZaffa || '—')}</td></tr>
      <tr><td>ملاحظات</td><td>${escapeHtml(b.notes || '—')}</td></tr>
    </table>
    <div class="totals">
      <div class="box t-total">الإجمالي<b>${b.totalAmount.toLocaleString('en-US')} ر.ع</b></div>
      <div class="box t-paid">المدفوع<b>${b.paidAmount.toLocaleString('en-US')} ر.ع</b></div>
      <div class="box t-rem">المتبقي<b>${rem.toLocaleString('en-US')} ر.ع</b></div>
    </div>
    <div class="status">حالة الدفع: ${statusText}${st !== 'paid' ? ` • رابط التذكير: ${waLinkFor(b).replace('https://', '')}` : ''}</div>
  </div>
  <div class="foot">صدر هذا الإيصال بتاريخ ${now} • ديجي مسقط — خدمات الحفلات والديجي المحلي • 968 XXXX XXXX</div>
</div>
<script>window.onload=function(){setTimeout(function(){window.print()},350)}</script>
</body></html>`);
  w.document.close();
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
